package com.castdz.app.core.motion

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext

/**
 * Provides subtle gyroscope/tilt parallax offsets for 3D icons.
 * Automatically disabled when system "Reduce Motion" is active or no sensor exists.
 */
@Composable
fun rememberGyroscopeParallax(maxOffsetPx: Float = 8f): State<Offset> {
    val reduceMotion = rememberReduceMotionEnabled()
    val context = LocalContext.current
    val offsetState = remember { mutableStateOf(Offset.Zero) }

    DisposableEffect(context, reduceMotion) {
        if (reduceMotion) {
            offsetState.value = Offset.Zero
            return@DisposableEffect onDispose {}
        }

        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val sensor = sensorManager?.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
            ?: sensorManager?.getDefaultSensor(Sensor.TYPE_GRAVITY)

        if (sensorManager == null || sensor == null) {
            return@DisposableEffect onDispose {}
        }

        var smoothX = 0f
        var smoothY = 0f
        val alpha = 0.12f

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                val targetX = (event.values[1] * maxOffsetPx).coerceIn(-maxOffsetPx, maxOffsetPx)
                val targetY = (event.values[0] * maxOffsetPx).coerceIn(-maxOffsetPx, maxOffsetPx)
                smoothX += alpha * (targetX - smoothX)
                smoothY += alpha * (targetY - smoothY)
                offsetState.value = Offset(smoothX, smoothY)
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
        }

        sensorManager.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
        onDispose {
            sensorManager.unregisterListener(listener)
        }
    }

    return offsetState
}
