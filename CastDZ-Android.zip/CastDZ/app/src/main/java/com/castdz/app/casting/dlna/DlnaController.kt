package com.castdz.app.casting.dlna

import com.castdz.app.core.network.WifiNetworkBinder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import javax.inject.Inject
import javax.inject.Singleton

/**
 * UPnP / DLNA AVTransport:1 and RenderingControl:1 SOAP controller
 * bound to the active Wi-Fi network.
 */
@Singleton
class DlnaController @Inject constructor(
    private val baseOkHttpClient: OkHttpClient,
    private val wifiNetworkBinder: WifiNetworkBinder
) {
    private val avTransportUrn = "urn:schemas-upnp-org:service:AVTransport:1"
    private val renderingControlUrn = "urn:schemas-upnp-org:service:RenderingControl:1"
    private val xmlMediaType = "text/xml; charset=\"utf-8\"".toMediaType()

    private fun wifiClient(): OkHttpClient {
        val wifiNet = wifiNetworkBinder.getWifiNetwork()
        return if (wifiNet != null) {
            baseOkHttpClient.newBuilder().socketFactory(wifiNet.socketFactory).build()
        } else {
            baseOkHttpClient
        }
    }

    suspend fun setAvTransportUri(
        controlUrl: String,
        mediaUrl: String,
        title: String,
        mimeType: String
    ): Boolean = withContext(Dispatchers.IO) {
        val escapedUrl = escapeXml(mediaUrl)
        val didl = escapeXml(
            """<DIDL-Lite xmlns="urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:upnp="urn:schemas-upnp-org:metadata-1-0/upnp/"><item id="1" parentID="0" restricted="1"><dc:title>${escapeXml(title)}</dc:title><res protocolInfo="http-get:*:${mimeType}:*">$escapedUrl</res></item></DIDL-Lite>"""
        )
        val body = """
            <u:SetAVTransportURI xmlns:u="$avTransportUrn">
                <InstanceID>0</InstanceID>
                <CurrentURI>$escapedUrl</CurrentURI>
                <CurrentURIMetaData>$didl</CurrentURIMetaData>
            </u:SetAVTransportURI>
        """.trimIndent()
        sendSoapAction(controlUrl, avTransportUrn, "SetAVTransportURI", body)
    }

    suspend fun play(controlUrl: String): Boolean = withContext(Dispatchers.IO) {
        val body = """
            <u:Play xmlns:u="$avTransportUrn">
                <InstanceID>0</InstanceID>
                <Speed>1</Speed>
            </u:Play>
        """.trimIndent()
        sendSoapAction(controlUrl, avTransportUrn, "Play", body)
    }

    suspend fun pause(controlUrl: String): Boolean = withContext(Dispatchers.IO) {
        val body = """
            <u:Pause xmlns:u="$avTransportUrn">
                <InstanceID>0</InstanceID>
            </u:Pause>
        """.trimIndent()
        sendSoapAction(controlUrl, avTransportUrn, "Pause", body)
    }

    suspend fun stop(controlUrl: String): Boolean = withContext(Dispatchers.IO) {
        val body = """
            <u:Stop xmlns:u="$avTransportUrn">
                <InstanceID>0</InstanceID>
            </u:Stop>
        """.trimIndent()
        sendSoapAction(controlUrl, avTransportUrn, "Stop", body)
    }

    suspend fun seek(controlUrl: String, positionMs: Long): Boolean = withContext(Dispatchers.IO) {
        val target = formatDlnaTime(positionMs)
        val body = """
            <u:Seek xmlns:u="$avTransportUrn">
                <InstanceID>0</InstanceID>
                <Unit>REL_TIME</Unit>
                <Target>$target</Target>
            </u:Seek>
        """.trimIndent()
        sendSoapAction(controlUrl, avTransportUrn, "Seek", body)
    }

    suspend fun setVolume(renderingControlUrl: String, volume01: Float): Boolean = withContext(Dispatchers.IO) {
        val percent = (volume01.coerceIn(0f, 1f) * 100).toInt()
        val body = """
            <u:SetVolume xmlns:u="$renderingControlUrn">
                <InstanceID>0</InstanceID>
                <Channel>Master</Channel>
                <DesiredVolume>$percent</DesiredVolume>
            </u:SetVolume>
        """.trimIndent()
        sendSoapAction(renderingControlUrl, renderingControlUrn, "SetVolume", body)
    }

    private fun sendSoapAction(url: String, serviceUrn: String, action: String, innerBody: String): Boolean {
        val envelope = """
            <?xml version="1.0" encoding="utf-8"?>
            <s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
                <s:Body>$innerBody</s:Body>
            </s:Envelope>
        """.trimIndent()

        return runCatching {
            val request = Request.Builder()
                .url(url)
                .header("SOAPACTION", "\"$serviceUrn#$action\"")
                .post(envelope.toRequestBody(xmlMediaType))
                .build()
            wifiClient().newCall(request).execute().use { it.isSuccessful }
        }.getOrDefault(false)
    }

    private fun formatDlnaTime(ms: Long): String {
        val totalSeconds = (ms / 1000L).coerceAtLeast(0L)
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return "%02d:%02d:%02d".format(hours, minutes, seconds)
    }

    private fun escapeXml(input: String): String {
        return input
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }
}
