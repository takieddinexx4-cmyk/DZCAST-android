package com.castdz.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.castdz.app.core.motion.rememberGyroscopeParallax
import kotlin.math.roundToInt

/**
 * Layered depth-styled 3D icon with multi-stop gradient, top specular highlight,
 * soft colored shadow, and subtle gyroscope parallax.
 */
@Composable
fun Icon3D(
    imageVector: ImageVector,
    contentDescription: String?,
    gradientColors: List<Color>,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    iconSize: Dp = 24.dp,
    enableParallax: Boolean = true
) {
    val parallaxOffset by rememberGyroscopeParallax(maxOffsetPx = if (enableParallax) 5f else 0f)
    val shape = RoundedCornerShape(size * 0.32f)
    val glowColor = gradientColors.firstOrNull() ?: Color.Cyan

    Box(
        modifier = modifier
            .size(size)
            .shadow(
                elevation = 10.dp,
                shape = shape,
                ambientColor = glowColor.copy(alpha = 0.55f),
                spotColor = glowColor.copy(alpha = 0.65f)
            )
            .clip(shape)
            .background(Brush.linearGradient(gradientColors))
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = 0.6f), Color.White.copy(alpha = 0.08f))
                ),
                shape = shape
            ),
        contentAlignment = Alignment.Center
    ) {
        // Specular top gloss
        Box(
            modifier = Modifier
                .matchParentSize()
                .background(
                    Brush.verticalGradient(
                        0f to Color.White.copy(alpha = 0.30f),
                        0.45f to Color.Transparent
                    )
                )
        )
        // Subtle shadow copy for depth
        Icon(
            imageVector = imageVector,
            contentDescription = null,
            tint = Color.Black.copy(alpha = 0.25f),
            modifier = Modifier
                .size(iconSize)
                .offset {
                    IntOffset(
                        (parallaxOffset.x * 0.5f + 1.5f).roundToInt(),
                        (parallaxOffset.y * 0.5f + 2f).roundToInt()
                    )
                }
        )
        // Foreground icon with parallax
        Icon(
            imageVector = imageVector,
            contentDescription = contentDescription,
            tint = Color.White,
            modifier = Modifier
                .size(iconSize)
                .offset {
                    IntOffset(
                        parallaxOffset.x.roundToInt(),
                        parallaxOffset.y.roundToInt()
                    )
                }
        )
    }
}
