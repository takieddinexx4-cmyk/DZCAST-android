package com.castdz.app.di

import android.content.Context
import androidx.room.Room
import com.castdz.app.core.network.LocalNetworkSecurityInterceptor
import com.castdz.app.data.local.CastDzDatabase
import com.castdz.app.data.local.dao.BookmarkDao
import com.castdz.app.data.local.dao.FavoriteDao
import com.castdz.app.data.local.dao.HistoryDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): CastDzDatabase {
        return Room.databaseBuilder(
            context,
            CastDzDatabase::class.java,
            "castdz_db"
        ).fallbackToDestructiveMigration(dropAllTables = true)
            .build()
    }

    @Provides
    fun provideHistoryDao(db: CastDzDatabase): HistoryDao = db.historyDao()

    @Provides
    fun provideFavoriteDao(db: CastDzDatabase): FavoriteDao = db.favoriteDao()

    @Provides
    fun provideBookmarkDao(db: CastDzDatabase): BookmarkDao = db.bookmarkDao()

    @Provides
    @Singleton
    fun provideLocalOkHttpClient(): OkHttpClient {
        return OkHttpClient.Builder()
            .connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(5, TimeUnit.SECONDS)
            .writeTimeout(5, TimeUnit.SECONDS)
            .addInterceptor(LocalNetworkSecurityInterceptor())
            .build()
    }
}
