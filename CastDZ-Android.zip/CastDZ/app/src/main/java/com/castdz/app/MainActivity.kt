package com.castdz.app

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.castdz.app.ui.components.CastDzBackground
import com.castdz.app.ui.navigation.CastDzAppRoot
import com.castdz.app.ui.navigation.MainViewModel
import com.castdz.app.ui.theme.CastDzTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private val mainViewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val settings by mainViewModel.settings.collectAsStateWithLifecycle()
            CastDzTheme(themeMode = settings.themeMode) {
                CastDzBackground {
                    CastDzAppRoot(mainViewModel = mainViewModel)
                }
            }
        }
    }
}
