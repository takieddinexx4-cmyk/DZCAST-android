package com.castdz.app.casting

import android.content.Context
import android.net.Uri
import com.castdz.app.casting.dlna.DlnaController
import com.castdz.app.casting.model.CastMediaItem
import com.castdz.app.casting.model.CastPlaybackState
import com.castdz.app.casting.model.MediaSourceType
import com.castdz.app.casting.server.LocalMediaServer
import com.castdz.app.casting.server.WebReceiverSessionInfo
import com.castdz.app.casting.service.CastNotificationManager
import com.castdz.app.data.repository.UserDataRepository
import com.castdz.app.discovery.DiscoveryEngine
import com.castdz.app.discovery.model.CastDevice
import com.castdz.app.discovery.model.CastProtocol
import com.castdz.app.discovery.model.DeviceIconType
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaLoadRequestData
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.MediaTrack
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener
import com.google.android.gms.cast.framework.media.RemoteMediaClient
import com.google.android.gms.common.images.WebImage
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.Executors
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CastSessionController @Inject constructor(
    @ApplicationContext private val context: Context,
    private val discoveryEngine: DiscoveryEngine,
    private val dlnaController: DlnaController,
    private val localMediaServer: LocalMediaServer,
    private val notificationManager: CastNotificationManager,
    private val userDataRepository: UserDataRepository
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _playbackState = MutableStateFlow(CastPlaybackState())
    val playbackState: StateFlow<CastPlaybackState> = _playbackState.asStateFlow()

    private val _webReceiverInfo = MutableStateFlow(localMediaServer.getWebReceiverInfo())
    val webReceiverInfo: StateFlow<WebReceiverSessionInfo> = _webReceiverInfo.asStateFlow()

    private var positionTickerJob: Job? = null
    private var pendingMediaToCast: CastMediaItem? = null

    @Volatile
    private var castContextRef: CastContext? = null

    private val sessionListener = object : SessionManagerListener<CastSession> {
        override fun onSessionStarting(session: CastSession) {
            _playbackState.update { it.copy(isConnecting = true, errorMessage = null) }
        }

        override fun onSessionStarted(session: CastSession, sessionId: String) {
            val gmsDevice = session.castDevice
            val existing = discoveryEngine.devices.value.firstOrNull {
                it.id.equals(gmsDevice?.deviceId, ignoreCase = true) ||
                    (gmsDevice?.friendlyName != null && it.name == gmsDevice.friendlyName)
            }
            val connected = existing ?: CastDevice(
                id = gmsDevice?.deviceId?.lowercase() ?: sessionId,
                name = gmsDevice?.friendlyName ?: "Google Cast",
                model = gmsDevice?.modelName ?: "Chromecast",
                manufacturer = "Google",
                protocol = CastProtocol.CAST,
                ip = gmsDevice?.inetAddress?.hostAddress ?: ""
            )
            discoveryEngine.markDeviceConnected(connected.id)
            _playbackState.update {
                it.copy(
                    connectedDevice = connected,
                    isConnecting = false,
                    errorMessage = null
                )
            }
            updateNotification()
            pendingMediaToCast?.let { item ->
                pendingMediaToCast = null
                castMedia(item)
            }
        }

        override fun onSessionStartFailed(session: CastSession, error: Int) {
            discoveryEngine.markDeviceConnected(null)
            _playbackState.update {
                it.copy(isConnecting = false, errorMessage = "Cast connection failed (code $error)")
            }
        }

        override fun onSessionEnding(session: CastSession) = Unit

        override fun onSessionEnded(session: CastSession, error: Int) {
            onDisconnectedInternal()
        }

        override fun onSessionResuming(session: CastSession, sessionId: String) {
            _playbackState.update { it.copy(isConnecting = true) }
        }

        override fun onSessionResumed(session: CastSession, wasSuspended: Boolean) {
            onSessionStarted(session, session.sessionId ?: "resumed")
        }

        override fun onSessionResumeFailed(session: CastSession, error: Int) {
            onDisconnectedInternal()
        }

        override fun onSessionSuspended(session: CastSession, reason: Int) = Unit
    }

    init {
        runCatching {
            CastContext.getSharedInstance(context, Executors.newSingleThreadExecutor())
                .addOnSuccessListener { ctx ->
                    castContextRef = ctx
                    runCatching {
                        ctx.sessionManager.addSessionManagerListener(sessionListener, CastSession::class.java)
                    }
                }
        }

        localMediaServer.setOnReceiverPairedListener { clientIp ->
            scope.launch {
                val info = localMediaServer.getWebReceiverInfo()
                _webReceiverInfo.value = info
                val webTvDevice = CastDevice(
                    id = "web-receiver:$clientIp",
                    name = "TV Web Receiver ($clientIp)",
                    model = "CastDZ Web Receiver",
                    manufacturer = "Browser",
                    protocol = CastProtocol.WEB_RECEIVER,
                    ip = clientIp,
                    port = 8889,
                    iconType = DeviceIconType.WEB_TV,
                    isManual = true
                )
                // Keep paired Web Receiver pinned in DiscoveryEngine so closing dialogs never loses it!
                discoveryEngine.registerExternalDevice(webTvDevice)
                discoveryEngine.markDeviceConnected(webTvDevice.id)
                _playbackState.update {
                    it.copy(
                        connectedDevice = webTvDevice,
                        isConnecting = false,
                        errorMessage = null
                    )
                }
                updateNotification()
                pendingMediaToCast?.let { item ->
                    pendingMediaToCast = null
                    castMedia(item)
                }
            }
        }
    }

    fun startWebReceiver(regenerateCode: Boolean = false): WebReceiverSessionInfo {
        val info = localMediaServer.startWebReceiver(regenerateCode)
        _webReceiverInfo.value = info
        return info
    }

    fun connect(device: CastDevice) {
        runCatching {
            discoveryEngine.markDeviceConnecting(device.id)
            _playbackState.update { it.copy(isConnecting = true, errorMessage = null) }

            if (device.protocol == CastProtocol.CAST && device.mediaRouteId != null && !device.id.startsWith("fake-")) {
                val selected = discoveryEngine.selectGoogleCastRoute(device.mediaRouteId)
                if (selected) return
            }

            scope.launch {
                delay(250L)
                discoveryEngine.markDeviceConnected(device.id)
                _playbackState.update {
                    it.copy(
                        connectedDevice = device,
                        isConnecting = false,
                        errorMessage = null
                    )
                }
                updateNotification()
                pendingMediaToCast?.let { item ->
                    pendingMediaToCast = null
                    castMedia(item)
                }
            }
        }.onFailure { err ->
            discoveryEngine.markDeviceConnected(null)
            _playbackState.update {
                it.copy(isConnecting = false, errorMessage = err.message ?: "Connection failed")
            }
        }
    }

    fun disconnect() {
        val current = _playbackState.value.connectedDevice
        runCatching {
            when {
                current?.protocol == CastProtocol.CAST && !current.id.startsWith("fake-") -> {
                    castContextRef?.sessionManager?.endCurrentSession(true)
                }
                current?.protocol == CastProtocol.DLNA && current.controlUrl != null && !current.id.startsWith("fake-") -> {
                    scope.launch { dlnaController.stop(current.controlUrl) }
                }
                current?.protocol == CastProtocol.WEB_RECEIVER -> {
                    localMediaServer.disconnectWebReceiver()
                    _webReceiverInfo.value = localMediaServer.getWebReceiverInfo()
                }
            }
        }
        onDisconnectedInternal()
    }

    fun castMedia(item: CastMediaItem) {
        val device = _playbackState.value.connectedDevice
        if (device == null) {
            pendingMediaToCast = item
            return
        }

        scope.launch {
            val resolvedUrl = if (item.sourceType == MediaSourceType.LOCAL_FILE && item.localUri != null) {
                localMediaServer.hostContentUri(item.localUri, item.mimeType)
                    ?: run {
                        _playbackState.update { it.copy(errorMessage = "Connect to Wi-Fi to cast local files") }
                        return@launch
                    }
            } else {
                item.streamUrl
            }

            val resolvedItem = item.copy(streamUrl = resolvedUrl)
            _playbackState.update { state ->
                val updatedQueue = if (state.queue.any { it.id == resolvedItem.id }) {
                    state.queue
                } else {
                    state.queue + resolvedItem
                }
                state.copy(
                    currentMedia = resolvedItem,
                    queue = updatedQueue,
                    isPlaying = true,
                    isBuffering = false,
                    positionMs = 0L,
                    durationMs = resolvedItem.durationMs.takeIf { it > 0L } ?: 180_000L,
                    errorMessage = null
                )
            }

            userDataRepository.recordHistory(
                title = resolvedItem.title,
                url = resolvedItem.localUri?.toString() ?: resolvedItem.streamUrl,
                mimeType = resolvedItem.mimeType,
                thumbnailUrl = resolvedItem.thumbnailUrl,
                deviceName = device.name
            )

            when {
                device.id.startsWith("fake-") -> startPositionTicker()
                device.protocol == CastProtocol.WEB_RECEIVER -> {
                    localMediaServer.updateWebReceiverPlayback(
                        mediaUrl = resolvedItem.streamUrl,
                        title = resolvedItem.title,
                        mimeType = resolvedItem.mimeType,
                        isPlaying = true,
                        positionMs = 0L,
                        triggerSeek = true,
                        volume = _playbackState.value.volume,
                        subtitleUrl = resolvedItem.subtitleUrl,
                        subtitlesEnabled = _playbackState.value.subtitlesEnabled
                    )
                    startPositionTicker()
                }
                device.protocol == CastProtocol.CAST -> {
                    loadOnGoogleCast(resolvedItem)
                    startPositionTicker()
                }
                device.protocol == CastProtocol.DLNA && device.controlUrl != null -> {
                    val setOk = dlnaController.setAvTransportUri(
                        controlUrl = device.controlUrl,
                        mediaUrl = resolvedItem.streamUrl,
                        title = resolvedItem.title,
                        mimeType = resolvedItem.mimeType
                    )
                    if (setOk) {
                        dlnaController.play(device.controlUrl)
                        startPositionTicker()
                    } else {
                        _playbackState.update { it.copy(isPlaying = false, errorMessage = "DLNA TV rejected stream") }
                    }
                }
                else -> startPositionTicker()
            }
            updateNotification()
        }
    }

    fun addToQueue(item: CastMediaItem) {
        _playbackState.update { state ->
            if (state.queue.any { it.id == item.id }) state
            else state.copy(queue = state.queue + item)
        }
    }

    fun removeFromQueue(itemId: String) {
        _playbackState.update { state ->
            state.copy(queue = state.queue.filterNot { it.id == itemId })
        }
    }

    fun togglePlayPause() {
        val state = _playbackState.value
        val device = state.connectedDevice ?: return
        val nextPlaying = !state.isPlaying
        _playbackState.update { it.copy(isPlaying = nextPlaying) }

        when {
            device.id.startsWith("fake-") -> Unit
            device.protocol == CastProtocol.WEB_RECEIVER -> {
                localMediaServer.updateWebReceiverPlayback(isPlaying = nextPlaying)
            }
            device.protocol == CastProtocol.CAST -> {
                remoteMediaClient()?.let { client ->
                    if (nextPlaying) client.play() else client.pause()
                }
            }
            device.protocol == CastProtocol.DLNA && device.controlUrl != null -> {
                scope.launch {
                    if (nextPlaying) dlnaController.play(device.controlUrl)
                    else dlnaController.pause(device.controlUrl)
                }
            }
        }
        updateNotification()
    }

    fun seekTo(positionMs: Long) {
        val state = _playbackState.value
        val device = state.connectedDevice ?: return
        val clamped = positionMs.coerceIn(0L, state.durationMs.coerceAtLeast(1L))
        _playbackState.update { it.copy(positionMs = clamped) }

        when {
            device.id.startsWith("fake-") -> Unit
            device.protocol == CastProtocol.WEB_RECEIVER -> {
                localMediaServer.updateWebReceiverPlayback(positionMs = clamped, triggerSeek = true)
            }
            device.protocol == CastProtocol.CAST -> {
                remoteMediaClient()?.seek(clamped)
            }
            device.protocol == CastProtocol.DLNA && device.controlUrl != null -> {
                scope.launch { dlnaController.seek(device.controlUrl, clamped) }
            }
        }
    }

    fun setVolume(volume01: Float) {
        val clamped = volume01.coerceIn(0f, 1f)
        val device = _playbackState.value.connectedDevice ?: return
        _playbackState.update { it.copy(volume = clamped, isMuted = clamped == 0f) }

        when {
            device.id.startsWith("fake-") -> Unit
            device.protocol == CastProtocol.WEB_RECEIVER -> {
                localMediaServer.updateWebReceiverPlayback(volume = clamped)
            }
            device.protocol == CastProtocol.CAST -> {
                runCatching {
                    castContextRef?.sessionManager?.currentCastSession?.volume = clamped.toDouble()
                }
            }
            device.protocol == CastProtocol.DLNA && device.renderingControlUrl != null -> {
                scope.launch { dlnaController.setVolume(device.renderingControlUrl, clamped) }
            }
        }
    }

    fun toggleSubtitles(subtitleUrl: String? = null) {
        _playbackState.update { state ->
            val nextUrl = subtitleUrl ?: state.activeSubtitleUrl ?: state.currentMedia?.subtitleUrl
            val nextEnabled = if (subtitleUrl != null) true else !state.subtitlesEnabled
            state.copy(
                subtitlesEnabled = nextEnabled,
                activeSubtitleUrl = nextUrl
            )
        }
        val state = _playbackState.value
        if (state.connectedDevice?.protocol == CastProtocol.WEB_RECEIVER) {
            localMediaServer.updateWebReceiverPlayback(
                subtitleUrl = state.activeSubtitleUrl,
                subtitlesEnabled = state.subtitlesEnabled
            )
            return
        }
        val client = remoteMediaClient() ?: return
        if (state.subtitlesEnabled) {
            client.setActiveMediaTracks(longArrayOf(1L))
        } else {
            client.setActiveMediaTracks(longArrayOf())
        }
    }

    fun playNextInQueue() {
        val state = _playbackState.value
        val idx = state.queue.indexOfFirst { it.id == state.currentMedia?.id }
        if (idx >= 0 && idx + 1 < state.queue.size) {
            castMedia(state.queue[idx + 1])
        }
    }

    fun playPreviousInQueue() {
        val state = _playbackState.value
        val idx = state.queue.indexOfFirst { it.id == state.currentMedia?.id }
        if (idx > 0) {
            castMedia(state.queue[idx - 1])
        }
    }

    fun clearError() {
        _playbackState.update { it.copy(errorMessage = null) }
    }

    private fun loadOnGoogleCast(item: CastMediaItem) {
        val client = remoteMediaClient() ?: return
        runCatching {
            val metadataType = when {
                item.mimeType.startsWith("audio/") -> MediaMetadata.MEDIA_TYPE_MUSIC_TRACK
                item.mimeType.startsWith("image/") -> MediaMetadata.MEDIA_TYPE_PHOTO
                else -> MediaMetadata.MEDIA_TYPE_MOVIE
            }
            val metadata = MediaMetadata(metadataType).apply {
                putString(MediaMetadata.KEY_TITLE, item.title)
                item.subtitle?.let { putString(MediaMetadata.KEY_SUBTITLE, it) }
                item.thumbnailUrl?.let { addImage(WebImage(Uri.parse(it))) }
            }

            val infoBuilder = MediaInfo.Builder(item.streamUrl)
                .setStreamType(MediaInfo.STREAM_TYPE_BUFFERED)
                .setContentType(item.mimeType)
                .setMetadata(metadata)

            val subUrl = item.subtitleUrl ?: _playbackState.value.activeSubtitleUrl
            if (!subUrl.isNullOrBlank()) {
                val track = MediaTrack.Builder(1L, MediaTrack.TYPE_TEXT)
                    .setName("Subtitles")
                    .setSubtype(MediaTrack.SUBTYPE_SUBTITLES)
                    .setContentId(subUrl)
                    .setContentType("text/vtt")
                    .setLanguage("en")
                    .build()
                infoBuilder.setMediaTracks(listOf(track))
            }

            val request = MediaLoadRequestData.Builder()
                .setMediaInfo(infoBuilder.build())
                .setAutoplay(true)
                .build()
            client.load(request)
        }
    }

    private fun remoteMediaClient(): RemoteMediaClient? {
        return runCatching {
            castContextRef?.sessionManager?.currentCastSession?.remoteMediaClient
        }.getOrNull()
    }

    private fun startPositionTicker() {
        positionTickerJob?.cancel()
        positionTickerJob = scope.launch {
            while (isActive) {
                delay(1_000L)
                val state = _playbackState.value
                val device = state.connectedDevice ?: break
                if (device.protocol == CastProtocol.CAST && !device.id.startsWith("fake-")) {
                    val client = remoteMediaClient()
                    if (client != null) {
                        val pos = client.approximateStreamPosition
                        val dur = client.streamDuration.takeIf { it > 0 } ?: state.durationMs
                        _playbackState.update {
                            it.copy(
                                positionMs = pos.coerceAtLeast(0L),
                                durationMs = dur,
                                isPlaying = client.isPlaying,
                                isBuffering = client.isBuffering
                            )
                        }
                    }
                } else if (state.isPlaying) {
                    val nextPos = (state.positionMs + 1_000L).coerceAtMost(state.durationMs)
                    _playbackState.update { it.copy(positionMs = nextPos) }
                }
            }
        }
    }

    private fun onDisconnectedInternal() {
        positionTickerJob?.cancel()
        positionTickerJob = null
        discoveryEngine.markDeviceConnected(null)
        _playbackState.value = CastPlaybackState()
        notificationManager.cancel()
    }

    private fun updateNotification() {
        val state = _playbackState.value
        val device = state.connectedDevice ?: return
        notificationManager.showOrUpdate(
            title = state.currentMedia?.title ?: device.name,
            deviceName = device.name,
            isPlaying = state.isPlaying
        )
    }
}
