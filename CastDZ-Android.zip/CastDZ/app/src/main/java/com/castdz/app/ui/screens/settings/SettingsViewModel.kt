package com.castdz.app.ui.screens.settings

import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.castdz.app.data.preferences.AppLanguage
import com.castdz.app.data.preferences.AppThemeMode
import com.castdz.app.data.preferences.SettingsDataStore
import com.castdz.app.data.preferences.UserSettings
import com.castdz.app.data.preferences.VideoQuality
import com.castdz.app.discovery.DiscoveryEngine
import com.castdz.app.discovery.model.CastDevice
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsDataStore: SettingsDataStore,
    discoveryEngine: DiscoveryEngine
) : ViewModel() {

    val settings: StateFlow<UserSettings> = settingsDataStore.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UserSettings())

    val nearbyDevices: StateFlow<List<CastDevice>> = discoveryEngine.devices

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch {
            settingsDataStore.setLanguage(language)
            val locales = if (language == AppLanguage.SYSTEM) {
                LocaleListCompat.getEmptyLocaleList()
            } else {
                LocaleListCompat.forLanguageTags(language.tag)
            }
            AppCompatDelegate.setApplicationLocales(locales)
        }
    }

    fun setThemeMode(mode: AppThemeMode) {
        viewModelScope.launch { settingsDataStore.setThemeMode(mode) }
    }

    fun setVideoQuality(quality: VideoQuality) {
        viewModelScope.launch { settingsDataStore.setVideoQuality(quality) }
    }

    fun setDefaultDevice(device: CastDevice?) {
        viewModelScope.launch {
            settingsDataStore.setDefaultDevice(device?.id, device?.name)
        }
    }

    fun setFakeDevicesEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsDataStore.setFakeDevicesEnabled(enabled)
        }
    }
}
