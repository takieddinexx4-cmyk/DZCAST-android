package com.castdz.app.discovery

import android.content.Context
import android.net.wifi.WifiManager
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.castdz.app.core.network.WifiNetworkBinder
import com.castdz.app.core.permissions.DiscoveryPermissionHelper
import com.castdz.app.data.preferences.SettingsDataStore
import com.castdz.app.discovery.model.CastDevice
import com.castdz.app.discovery.model.CastProtocol
import com.castdz.app.discovery.model.DeviceConnectionState
import com.castdz.app.discovery.model.DeviceIconType
import com.castdz.app.discovery.model.DiagnosticCause
import com.castdz.app.discovery.model.DiscoveryDiagnostic
import com.castdz.app.discovery.scanner.GoogleCastScanner
import com.castdz.app.discovery.scanner.MdnsScanner
import com.castdz.app.discovery.scanner.SsdpScanner
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Unified multi-layer device discovery engine.
 * Merges Google Cast (MediaRouter), mDNS (NsdManager), SSDP/UPnP (UDP multicast),
 * manual IP entries, and optional debug fake devices into one deduplicated Flow.
 */
@Singleton
class DiscoveryEngine @Inject constructor(
    @ApplicationContext private val context: Context,
    private val wifiNetworkBinder: WifiNetworkBinder,
    private val googleCastScanner: GoogleCastScanner,
    private val mdnsScanner: MdnsScanner,
    private val ssdpScanner: SsdpScanner,
    private val settingsDataStore: SettingsDataStore
) : DefaultLifecycleObserver {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val wifiManager =
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    private var multicastLock: WifiManager.MulticastLock? = null
    private var activeScanJob: Job? = null
    private var diagnosticTimerJob: Job? = null

    private val deviceMap = ConcurrentHashMap<String, CastDevice>()
    private val manualDevices = ConcurrentHashMap<String, CastDevice>()

    @Volatile
    private var isSheetOpen: Boolean = false

    @Volatile
    private var isAppInForeground: Boolean = true

    @Volatile
    private var fakeDevicesEnabled: Boolean = false

    @Volatile
    private var connectedDeviceId: String? = null

    @Volatile
    private var connectingDeviceId: String? = null

    private val _devices = MutableStateFlow<List<CastDevice>>(emptyList())
    val devices: StateFlow<List<CastDevice>> = _devices.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _diagnostics = MutableStateFlow<List<DiscoveryDiagnostic>>(emptyList())
    val diagnostics: StateFlow<List<DiscoveryDiagnostic>> = _diagnostics.asStateFlow()

    init {
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)

        scope.launch {
            settingsDataStore.settings.collectLatest { settings ->
                fakeDevicesEnabled = settings.fakeDevicesEnabled
                publishMergedDevices()
            }
        }

        // Restart scanning automatically when the Wi-Fi network changes
        scope.launch {
            var lastGen = -1
            wifiNetworkBinder.networkStatus.collectLatest { status ->
                if (lastGen != -1 && status.networkGeneration != lastGen && isAppInForeground) {
                    deviceMap.clear()
                    publishMergedDevices()
                    if (isSheetOpen) {
                        restartActiveScan()
                    } else {
                        startPassiveScan()
                    }
                }
                lastGen = status.networkGeneration
            }
        }
    }

    override fun onStart(owner: LifecycleOwner) {
        isAppInForeground = true
        if (isSheetOpen) {
            restartActiveScan()
        } else {
            startPassiveScan()
        }
    }

    override fun onStop(owner: LifecycleOwner) {
        isAppInForeground = false
        stopAllScanning()
    }

    fun onDeviceSheetOpened() {
        isSheetOpen = true
        if (isAppInForeground) {
            restartActiveScan()
        }
    }

    fun onDeviceSheetClosed() {
        isSheetOpen = false
        if (isAppInForeground) {
            startPassiveScan()
        } else {
            stopAllScanning()
        }
    }

    fun refreshNow() {
        wifiNetworkBinder.refreshStatus(incrementGeneration = false)
        if (isSheetOpen) {
            restartActiveScan()
        } else {
            startPassiveScan()
        }
    }

    fun markDeviceConnecting(deviceId: String?) {
        connectingDeviceId = deviceId
        publishMergedDevices()
    }

    fun markDeviceConnected(deviceId: String?) {
        connectingDeviceId = null
        connectedDeviceId = deviceId
        publishMergedDevices()
    }

    fun registerExternalDevice(device: CastDevice) {
        manualDevices[device.id] = device
        publishMergedDevices()
    }

    fun addManualDevice(ip: String, name: String?, protocol: CastProtocol) {
        val cleanIp = ip.trim()
        if (cleanIp.isEmpty()) return
        val id = "manual:${protocol.name.lowercase()}:$cleanIp"
        val device = CastDevice(
            id = id,
            name = name?.takeIf { it.isNotBlank() } ?: "TV ($cleanIp)",
            model = "${protocol.name} Device",
            manufacturer = "Manual",
            protocol = protocol,
            ip = cleanIp,
            port = when (protocol) {
                CastProtocol.CAST -> 8009
                CastProtocol.ROKU -> 8060
                CastProtocol.AIRPLAY -> 7000
                CastProtocol.DLNA -> 49152
                CastProtocol.WEB_RECEIVER -> 8889
            },
            controlUrl = if (protocol == CastProtocol.DLNA) "http://$cleanIp:49152/upnp/control/AVTransport1" else null,
            iconType = when (protocol) {
                CastProtocol.CAST -> DeviceIconType.CHROMECAST
                CastProtocol.ROKU -> DeviceIconType.ROKU
                CastProtocol.AIRPLAY -> DeviceIconType.APPLE_TV
                CastProtocol.DLNA -> DeviceIconType.TV
                CastProtocol.WEB_RECEIVER -> DeviceIconType.WEB_TV
            },
            lastSeen = System.currentTimeMillis(),
            isManual = true
        )
        manualDevices[id] = device
        publishMergedDevices()
    }

    fun selectGoogleCastRoute(routeId: String): Boolean {
        return googleCastScanner.selectRouteById(routeId)
    }

    private fun startPassiveScan() {
        stopAllScanning()
        _isScanning.value = false
        _diagnostics.value = emptyList()

        activeScanJob = scope.launch {
            launch {
                googleCastScanner.scan(activeScan = false).collect { list ->
                    list.forEach { upsertDevice(it) }
                    publishMergedDevices()
                }
            }
            launch { runEvictionLoop() }
        }
    }

    private fun restartActiveScan() {
        stopAllScanning()
        acquireMulticastLock()
        _isScanning.value = true
        _diagnostics.value = emptyList()

        activeScanJob = scope.launch {
            // Layer 1: Google Cast MediaRouter (active scan)
            launch {
                googleCastScanner.scan(activeScan = true).collect { list ->
                    list.forEach { upsertDevice(it) }
                    publishMergedDevices()
                }
            }
            // Layer 2: mDNS / DNS-SD
            launch {
                mdnsScanner.scan().collect { device ->
                    upsertDevice(device)
                    publishMergedDevices()
                }
            }
            // Layer 3: SSDP / UPnP / Roku
            launch {
                ssdpScanner.scan().collect { device ->
                    upsertDevice(device)
                    publishMergedDevices()
                }
            }
            // 30-second stale device eviction
            launch { runEvictionLoop() }
        }

        // 8-second diagnostic check if no devices found
        diagnosticTimerJob = scope.launch {
            delay(8_000L)
            if (_devices.value.isEmpty()) {
                _diagnostics.value = evaluateDiagnostics()
            }
        }
    }

    private suspend fun runEvictionLoop() {
        while (true) {
            delay(5_000L)
            val cutoff = System.currentTimeMillis() - EVICTION_TIMEOUT_MS
            var removed = false
            val iter = deviceMap.entries.iterator()
            while (iter.hasNext()) {
                val entry = iter.next()
                if (!entry.value.isManual && entry.value.lastSeen < cutoff && entry.value.id != connectedDeviceId) {
                    iter.remove()
                    removed = true
                }
            }
            if (removed) {
                publishMergedDevices()
            }
        }
    }

    private fun stopAllScanning() {
        activeScanJob?.cancel()
        activeScanJob = null
        diagnosticTimerJob?.cancel()
        diagnosticTimerJob = null
        _isScanning.value = false
        releaseMulticastLock()
    }

    private fun acquireMulticastLock() {
        runCatching {
            if (multicastLock == null) {
                multicastLock = wifiManager.createMulticastLock("CastDZ_Discovery_Lock").apply {
                    setReferenceCounted(false)
                }
            }
            if (multicastLock?.isHeld == false) {
                multicastLock?.acquire()
            }
        }
    }

    private fun releaseMulticastLock() {
        runCatching {
            if (multicastLock?.isHeld == true) {
                multicastLock?.release()
            }
        }
    }

    /**
     * Deduplicate by UUID (id), falling back to IP address.
     * Merges richer fields (e.g., MediaRouteId from Google Cast + IP from mDNS).
     */
    private fun upsertDevice(incoming: CastDevice) {
        val existingKey = deviceMap.entries.firstOrNull { (_, existing) ->
            existing.id.equals(incoming.id, ignoreCase = true) ||
                (incoming.ip.isNotBlank() && existing.ip.isNotBlank() && existing.ip == incoming.ip && existing.protocol == incoming.protocol)
        }?.key

        if (existingKey != null) {
            val prev = deviceMap[existingKey]!!
            val merged = prev.copy(
                name = incoming.name.ifBlank { prev.name },
                model = if (incoming.model != "Cast Device" && incoming.model.isNotBlank()) incoming.model else prev.model,
                manufacturer = if (incoming.manufacturer != "Unknown") incoming.manufacturer else prev.manufacturer,
                ip = incoming.ip.ifBlank { prev.ip },
                port = if (incoming.port > 0) incoming.port else prev.port,
                controlUrl = incoming.controlUrl ?: prev.controlUrl,
                renderingControlUrl = incoming.renderingControlUrl ?: prev.renderingControlUrl,
                mediaRouteId = incoming.mediaRouteId ?: prev.mediaRouteId,
                lastSeen = maxOf(prev.lastSeen, incoming.lastSeen)
            )
            deviceMap[existingKey] = merged
        } else {
            deviceMap[incoming.id] = incoming
        }
    }

    private fun publishMergedDevices() {
        val combined = LinkedHashMap<String, CastDevice>()
        deviceMap.values.forEach { combined[it.id] = it }
        manualDevices.values.forEach { combined[it.id] = it }
        if (fakeDevicesEnabled) {
            fakeDebugDevices().forEach { combined.putIfAbsent(it.id, it) }
        }

        val finalList = combined.values
            .map { dev ->
                val state = when (dev.id) {
                    connectedDeviceId -> DeviceConnectionState.CONNECTED
                    connectingDeviceId -> DeviceConnectionState.CONNECTING
                    else -> DeviceConnectionState.AVAILABLE
                }
                dev.copy(state = state)
            }
            .sortedWith(
                compareByDescending<CastDevice> { it.state == DeviceConnectionState.CONNECTED }
                    .thenByDescending { it.state == DeviceConnectionState.CONNECTING }
                    .thenBy { it.name.lowercase() }
            )

        _devices.value = finalList
        if (finalList.isNotEmpty()) {
            _diagnostics.value = emptyList()
        }
    }

    private fun evaluateDiagnostics(): List<DiscoveryDiagnostic> {
        wifiNetworkBinder.refreshStatus(incrementGeneration = false)
        val status = wifiNetworkBinder.networkStatus.value
        val result = mutableListOf<DiscoveryDiagnostic>()

        if (!wifiNetworkBinder.isWifiEnabled()) {
            result.add(DiscoveryDiagnostic(DiagnosticCause.WIFI_OFF, canOneTapFix = true))
        } else if (status.isMobileDataOnly || !status.isWifiConnected) {
            result.add(DiscoveryDiagnostic(DiagnosticCause.MOBILE_DATA_ONLY, canOneTapFix = true))
        }
        if (!DiscoveryPermissionHelper.hasDiscoveryPermissions(context)) {
            result.add(DiscoveryDiagnostic(DiagnosticCause.PERMISSION_DENIED, canOneTapFix = true))
        }
        if (status.isVpnActive) {
            result.add(DiscoveryDiagnostic(DiagnosticCause.VPN_ACTIVE, canOneTapFix = true))
        }
        // Always include AP/client isolation hint if Wi-Fi is connected and still nothing found
        if (status.isWifiConnected) {
            result.add(DiscoveryDiagnostic(DiagnosticCause.AP_ISOLATION, canOneTapFix = false))
        }
        return result
    }

    private fun fakeDebugDevices(): List<CastDevice> {
        val now = System.currentTimeMillis()
        return listOf(
            CastDevice(
                id = "fake-chromecast-living",
                name = "Living Room TV",
                model = "Chromecast with Google TV",
                manufacturer = "Google",
                protocol = CastProtocol.CAST,
                ip = "192.168.1.42",
                iconType = DeviceIconType.CHROMECAST,
                lastSeen = now
            ),
            CastDevice(
                id = "fake-samsung-dlna",
                name = "Samsung QLED 65\"",
                model = "QN65Q80C",
                manufacturer = "Samsung",
                protocol = CastProtocol.DLNA,
                ip = "192.168.1.55",
                controlUrl = "http://192.168.1.55:9197/upnp/control/AVTransport1",
                iconType = DeviceIconType.TV,
                lastSeen = now
            ),
            CastDevice(
                id = "fake-appletv-bedroom",
                name = "Bedroom Apple TV",
                model = "Apple TV 4K",
                manufacturer = "Apple",
                protocol = CastProtocol.AIRPLAY,
                ip = "192.168.1.68",
                port = 7000,
                iconType = DeviceIconType.APPLE_TV,
                lastSeen = now
            ),
            CastDevice(
                id = "fake-roku-studio",
                name = "Studio Roku",
                model = "Roku Streaming Stick 4K",
                manufacturer = "Roku",
                protocol = CastProtocol.ROKU,
                ip = "192.168.1.73",
                port = 8060,
                iconType = DeviceIconType.ROKU,
                lastSeen = now
            )
        )
    }

    companion object {
        private const val EVICTION_TIMEOUT_MS = 30_000L
    }
}
