package com.castdz.app.discovery.scanner

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.mediarouter.media.MediaRouteSelector
import androidx.mediarouter.media.MediaRouter
import com.castdz.app.discovery.model.CastDevice
import com.castdz.app.discovery.model.CastProtocol
import com.castdz.app.discovery.model.DeviceConnectionState
import com.castdz.app.discovery.model.DeviceIconType
import com.google.android.gms.cast.CastMediaControlIntent
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Layer 1: Official Google Cast discovery via MediaRouter + MediaRouteSelector.
 * Uses active scanning when the device picker sheet is visible, passive scanning otherwise.
 */
@Singleton
class GoogleCastScanner @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val mainHandler = Handler(Looper.getMainLooper())

    fun scan(activeScan: Boolean): Flow<List<CastDevice>> = callbackFlow {
        val selector = MediaRouteSelector.Builder()
            .addControlCategory(
                CastMediaControlIntent.categoryForCast(
                    CastMediaControlIntent.DEFAULT_MEDIA_RECEIVER_APPLICATION_ID
                )
            )
            .build()

        var mediaRouter: MediaRouter? = null
        val callback = object : MediaRouter.Callback() {
            override fun onRouteAdded(router: MediaRouter, route: MediaRouter.RouteInfo) {
                emitRoutes(router, selector)
            }

            override fun onRouteChanged(router: MediaRouter, route: MediaRouter.RouteInfo) {
                emitRoutes(router, selector)
            }

            override fun onRouteRemoved(router: MediaRouter, route: MediaRouter.RouteInfo) {
                emitRoutes(router, selector)
            }

            override fun onRouteSelected(router: MediaRouter, route: MediaRouter.RouteInfo, reason: Int) {
                emitRoutes(router, selector)
            }

            override fun onRouteUnselected(router: MediaRouter, route: MediaRouter.RouteInfo, reason: Int) {
                emitRoutes(router, selector)
            }

            private fun emitRoutes(router: MediaRouter, sel: MediaRouteSelector) {
                val now = System.currentTimeMillis()
                val devices = router.routes
                    .filter { !it.isDefault && it.matchesSelector(sel) && it.isEnabled }
                    .map { route -> routeToCastDevice(route, now) }
                trySend(devices)
            }
        }

        mainHandler.post {
            runCatching {
                val router = MediaRouter.getInstance(context)
                mediaRouter = router
                val flags = if (activeScan) {
                    MediaRouter.CALLBACK_FLAG_PERFORM_ACTIVE_SCAN
                } else {
                    MediaRouter.CALLBACK_FLAG_REQUEST_DISCOVERY
                }
                router.addCallback(selector, callback, flags)
                // Emit immediately available cached routes
                val now = System.currentTimeMillis()
                val initial = router.routes
                    .filter { !it.isDefault && it.matchesSelector(selector) && it.isEnabled }
                    .map { routeToCastDevice(it, now) }
                trySend(initial)
            }
        }

        awaitClose {
            mainHandler.post {
                runCatching {
                    mediaRouter?.removeCallback(callback)
                }
            }
        }
    }

    fun selectRouteById(routeId: String): Boolean {
        var selected = false
        mainHandler.post {
            runCatching {
                val router = MediaRouter.getInstance(context)
                val match = router.routes.firstOrNull { it.id == routeId }
                if (match != null) {
                    router.selectRoute(match)
                    selected = true
                }
            }
        }
        return selected
    }

    private fun routeToCastDevice(route: MediaRouter.RouteInfo, now: Long): CastDevice {
        val extras = route.extras
        val castDeviceObj = extras?.let {
            runCatching { com.google.android.gms.cast.CastDevice.getFromBundle(it) }.getOrNull()
        }
        val ip = castDeviceObj?.inetAddress?.hostAddress ?: ""
        val model = castDeviceObj?.modelName?.takeIf { it.isNotBlank() }
            ?: route.description?.takeIf { it.isNotBlank() }
            ?: "Chromecast"
        val deviceId = castDeviceObj?.deviceId?.takeIf { it.isNotBlank() } ?: route.id
        val state = when {
            route.isSelected && route.isConnecting -> DeviceConnectionState.CONNECTING
            route.isSelected -> DeviceConnectionState.CONNECTED
            else -> DeviceConnectionState.AVAILABLE
        }
        val iconType = when {
            model.contains("speaker", ignoreCase = true) ||
                model.contains("mini", ignoreCase = true) ||
                model.contains("audio", ignoreCase = true) -> DeviceIconType.SPEAKER
            model.contains("chromecast", ignoreCase = true) -> DeviceIconType.CHROMECAST
            else -> DeviceIconType.TV
        }
        return CastDevice(
            id = deviceId.lowercase(),
            name = route.name.ifBlank { model },
            model = model,
            manufacturer = "Google Cast",
            protocol = CastProtocol.CAST,
            ip = ip,
            port = castDeviceObj?.servicePort ?: 8009,
            mediaRouteId = route.id,
            iconType = iconType,
            state = state,
            lastSeen = now
        )
    }
}
