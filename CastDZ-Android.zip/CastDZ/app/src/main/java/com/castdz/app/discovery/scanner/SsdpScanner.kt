package com.castdz.app.discovery.scanner

import com.castdz.app.core.network.WifiNetworkBinder
import com.castdz.app.discovery.model.CastDevice
import com.castdz.app.discovery.model.CastProtocol
import com.castdz.app.discovery.model.DeviceIconType
import com.castdz.app.discovery.parser.SsdpParser
import com.castdz.app.discovery.parser.UpnpDescriptionParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.DatagramPacket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.MulticastSocket
import java.net.SocketTimeoutException
import java.net.URI
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Layer 3: SSDP UDP multicast scanner (239.255.255.250:1900) bound to the Wi-Fi network.
 * Sends M-SEARCH for MediaRenderer:1, ssdp:all, and roku:ecp every 2s for the first 10s,
 * then every 15s thereafter. Fetches each LOCATION description XML and parses AVTransport URLs.
 */
@Singleton
class SsdpScanner @Inject constructor(
    private val wifiNetworkBinder: WifiNetworkBinder,
    private val baseOkHttpClient: OkHttpClient
) {
    private val multicastHost = "239.255.255.250"
    private val multicastPort = 1900

    private val searchTargets = listOf(
        "urn:schemas-upnp-org:device:MediaRenderer:1",
        "ssdp:all",
        "roku:ecp"
    )

    fun scan(): Flow<CastDevice> = channelFlow {
        val fetchedLocations = ConcurrentHashMap<String, Long>()
        val socket = MulticastSocket(null).apply {
            reuseAddress = true
            soTimeout = 1500
            bind(InetSocketAddress(0))
        }

        val wifiNet = wifiNetworkBinder.getWifiNetwork()
        val wifiHttpClient = if (wifiNet != null) {
            baseOkHttpClient.newBuilder()
                .socketFactory(wifiNet.socketFactory)
                .build()
        } else {
            baseOkHttpClient
        }

        // Bind multicast UDP socket to Wi-Fi network so traffic works even with mobile data enabled
        runCatching {
            wifiNet?.bindSocket(socket)
        }

        val group = InetAddress.getByName(multicastHost)
        runCatching { socket.joinGroup(group) }

        // Sender coroutine: every 2s for first 10s (5 bursts), then every 15s
        val senderJob = launch(Dispatchers.IO) {
            var burstCount = 0
            while (isActive) {
                for (st in searchTargets) {
                    val payload = buildMSearchPacket(st).toByteArray(Charsets.UTF_8)
                    val packet = DatagramPacket(payload, payload.size, group, multicastPort)
                    runCatching { socket.send(packet) }
                }
                burstCount++
                delay(if (burstCount < 5) 2_000L else 15_000L)
            }
        }

        // Receiver loop
        val receiverJob = launch(Dispatchers.IO) {
            val buffer = ByteArray(4096)
            while (currentCoroutineContext().isActive) {
                val packet = DatagramPacket(buffer, buffer.size)
                try {
                    socket.receive(packet)
                    val raw = String(packet.data, 0, packet.length, Charsets.UTF_8)
                    val senderIp = packet.address?.hostAddress ?: continue
                    val parsed = SsdpParser.parse(raw) ?: continue
                    val location = parsed.location ?: continue

                    val now = System.currentTimeMillis()
                    val lastFetch = fetchedLocations[location] ?: 0L
                    if (now - lastFetch < 8_000L) continue
                    fetchedLocations[location] = now

                    launch(Dispatchers.IO) {
                        val device = fetchAndBuildDevice(
                            client = wifiHttpClient,
                            location = location,
                            senderIp = senderIp,
                            usnUuid = parsed.uuid,
                            isRoku = parsed.isRoku
                        )
                        if (device != null) {
                            trySend(device)
                        }
                    }
                } catch (_: SocketTimeoutException) {
                    // Normal polling timeout to allow coroutine cancellation checks
                } catch (_: Exception) {
                    if (!isActive) break
                }
            }
        }

        try {
            receiverJob.join()
        } finally {
            senderJob.cancel()
            receiverJob.cancel()
            runCatching { socket.leaveGroup(group) }
            runCatching { socket.close() }
        }
    }

    private fun buildMSearchPacket(searchTarget: String): String {
        return buildString {
            append("M-SEARCH * HTTP/1.1\r\n")
            append("HOST: $multicastHost:$multicastPort\r\n")
            append("MAN: \"ssdp:discover\"\r\n")
            append("MX: 2\r\n")
            append("ST: $searchTarget\r\n")
            append("USER-AGENT: CastDZ/1.0 UPnP/1.1\r\n")
            append("\r\n")
        }
    }

    private fun fetchAndBuildDevice(
        client: OkHttpClient,
        location: String,
        senderIp: String,
        usnUuid: String?,
        isRoku: Boolean
    ): CastDevice? {
        val xml = runCatching {
            val request = Request.Builder().url(location).get().build()
            client.newCall(request).execute().use { resp ->
                if (!resp.isSuccessful) null else resp.body?.string()
            }
        }.getOrNull() ?: return null

        val desc = UpnpDescriptionParser.parse(xml, location) ?: return null

        // Filter out non-media routers/gateways unless it is a Roku or has AVTransport
        val isMediaRenderer = desc.avTransportControlUrl != null ||
            desc.deviceType?.contains("MediaRenderer", ignoreCase = true) == true ||
            isRoku ||
            desc.manufacturer.contains("roku", ignoreCase = true)
        if (!isMediaRenderer) return null

        val protocol = if (isRoku || desc.manufacturer.contains("roku", ignoreCase = true)) {
            CastProtocol.ROKU
        } else {
            CastProtocol.DLNA
        }

        val port = runCatching { URI(location).port }.getOrDefault(-1).let { if (it > 0) it else 8060 }
        val id = desc.udn ?: usnUuid ?: "${protocol.name.lowercase()}:$senderIp"

        return CastDevice(
            id = id,
            name = desc.friendlyName,
            model = desc.modelName,
            manufacturer = desc.manufacturer,
            protocol = protocol,
            ip = senderIp,
            port = port,
            controlUrl = desc.avTransportControlUrl,
            renderingControlUrl = desc.renderingControlUrl,
            iconType = if (protocol == CastProtocol.ROKU) DeviceIconType.ROKU else DeviceIconType.TV,
            lastSeen = System.currentTimeMillis()
        )
    }
}
