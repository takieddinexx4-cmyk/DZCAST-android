package com.castdz.app.core.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.net.Inet4Address
import java.net.NetworkInterface
import javax.inject.Inject
import javax.inject.Singleton

data class NetworkStatus(
    val isWifiConnected: Boolean = false,
    val isMobileDataOnly: Boolean = false,
    val isVpnActive: Boolean = false,
    val wifiNetwork: Network? = null,
    val localIpAddress: String? = null,
    val networkGeneration: Int = 0
)

@Singleton
class WifiNetworkBinder @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val wifiManager =
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    private val _networkStatus = MutableStateFlow(readCurrentStatus())
    val networkStatus: StateFlow<NetworkStatus> = _networkStatus.asStateFlow()

    @Volatile
    private var activeWifiNetwork: Network? = findWifiNetwork()

    private val wifiCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            activeWifiNetwork = network
            refreshStatus(incrementGeneration = true)
        }

        override fun onLost(network: Network) {
            if (activeWifiNetwork == network) {
                activeWifiNetwork = findWifiNetwork()
            }
            refreshStatus(incrementGeneration = true)
        }

        override fun onCapabilitiesChanged(
            network: Network,
            networkCapabilities: NetworkCapabilities
        ) {
            if (networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                activeWifiNetwork = network
            }
            refreshStatus(incrementGeneration = false)
        }
    }

    init {
        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .build()
        runCatching {
            connectivityManager.registerNetworkCallback(request, wifiCallback)
        }
    }

    fun getWifiNetwork(): Network? = activeWifiNetwork ?: findWifiNetwork()

    fun isWifiEnabled(): Boolean = runCatching { wifiManager.isWifiEnabled }.getOrDefault(false)

    fun refreshStatus(incrementGeneration: Boolean = false) {
        val current = _networkStatus.value
        val updated = readCurrentStatus(
            generation = if (incrementGeneration) current.networkGeneration + 1 else current.networkGeneration
        )
        _networkStatus.value = updated
    }

    private fun readCurrentStatus(generation: Int = 0): NetworkStatus {
        val wifiNet = findWifiNetwork()
        val allNetworks = connectivityManager.allNetworks
        val hasVpn = allNetworks.any { net ->
            connectivityManager.getNetworkCapabilities(net)
                ?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
        }
        val hasCellular = allNetworks.any { net ->
            connectivityManager.getNetworkCapabilities(net)
                ?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
        }
        val ip = if (wifiNet != null) resolveLocalIpv4(wifiNet) else null
        return NetworkStatus(
            isWifiConnected = wifiNet != null,
            isMobileDataOnly = wifiNet == null && hasCellular,
            isVpnActive = hasVpn,
            wifiNetwork = wifiNet,
            localIpAddress = ip,
            networkGeneration = generation
        )
    }

    private fun findWifiNetwork(): Network? {
        return connectivityManager.allNetworks.firstOrNull { net ->
            val caps = connectivityManager.getNetworkCapabilities(net)
            caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
        }
    }

    fun resolveLocalIpv4(network: Network? = getWifiNetwork()): String? {
        // Prefer LinkProperties of the Wi-Fi network
        if (network != null) {
            val linkProps = connectivityManager.getLinkProperties(network)
            val ipv4 = linkProps?.linkAddresses
                ?.mapNotNull { it.address as? Inet4Address }
                ?.firstOrNull { !it.isLoopbackAddress && it.isSiteLocalAddress }
            if (ipv4 != null) return ipv4.hostAddress
        }
        // Fallback: enumerate wlan interfaces
        return runCatching {
            NetworkInterface.getNetworkInterfaces()?.toList()
                ?.filter { it.isUp && !it.isLoopback && (it.name.startsWith("wlan") || it.name.startsWith("ap")) }
                ?.flatMap { it.inetAddresses.toList() }
                ?.filterIsInstance<Inet4Address>()
                ?.firstOrNull { !it.isLoopbackAddress && it.isSiteLocalAddress }
                ?.hostAddress
        }.getOrNull()
    }
}
