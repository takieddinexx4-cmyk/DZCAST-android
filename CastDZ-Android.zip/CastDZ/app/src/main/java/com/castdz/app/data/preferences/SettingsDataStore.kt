package com.castdz.app.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.castDzDataStore: DataStore<Preferences> by preferencesDataStore(name = "castdz_settings")

enum class AppThemeMode { SYSTEM, DARK, LIGHT }
enum class AppLanguage(val tag: String) {
    SYSTEM(""),
    ENGLISH("en"),
    FRENCH("fr"),
    ARABIC("ar");

    companion object {
        fun fromTag(tag: String): AppLanguage = entries.firstOrNull { it.tag == tag } ?: SYSTEM
    }
}

enum class VideoQuality(val label: String) {
    AUTO("Auto"),
    HD_1080("1080p"),
    HD_720("720p"),
    SD_480("480p");

    companion object {
        fun fromName(name: String): VideoQuality = entries.firstOrNull { it.name == name } ?: AUTO
    }
}

data class UserSettings(
    val themeMode: AppThemeMode = AppThemeMode.DARK,
    val language: AppLanguage = AppLanguage.SYSTEM,
    val defaultDeviceId: String? = null,
    val defaultDeviceName: String? = null,
    val videoQuality: VideoQuality = VideoQuality.AUTO,
    val onboardingCompleted: Boolean = false,
    val fakeDevicesEnabled: Boolean = false
)

@Singleton
class SettingsDataStore @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val LANGUAGE = stringPreferencesKey("language")
        val DEFAULT_DEVICE_ID = stringPreferencesKey("default_device_id")
        val DEFAULT_DEVICE_NAME = stringPreferencesKey("default_device_name")
        val VIDEO_QUALITY = stringPreferencesKey("video_quality")
        val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
        val FAKE_DEVICES_ENABLED = booleanPreferencesKey("fake_devices_enabled")
    }

    val settings: Flow<UserSettings> = context.castDzDataStore.data.map { prefs ->
        UserSettings(
            themeMode = prefs[Keys.THEME_MODE]
                ?.let { runCatching { AppThemeMode.valueOf(it) }.getOrNull() }
                ?: AppThemeMode.DARK,
            language = AppLanguage.fromTag(prefs[Keys.LANGUAGE] ?: ""),
            defaultDeviceId = prefs[Keys.DEFAULT_DEVICE_ID],
            defaultDeviceName = prefs[Keys.DEFAULT_DEVICE_NAME],
            videoQuality = VideoQuality.fromName(prefs[Keys.VIDEO_QUALITY] ?: VideoQuality.AUTO.name),
            onboardingCompleted = prefs[Keys.ONBOARDING_COMPLETED] ?: false,
            fakeDevicesEnabled = prefs[Keys.FAKE_DEVICES_ENABLED] ?: false
        )
    }

    suspend fun setThemeMode(mode: AppThemeMode) {
        context.castDzDataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.castDzDataStore.edit { it[Keys.LANGUAGE] = language.tag }
    }

    suspend fun setDefaultDevice(id: String?, name: String?) {
        context.castDzDataStore.edit { prefs ->
            if (id == null || name == null) {
                prefs.remove(Keys.DEFAULT_DEVICE_ID)
                prefs.remove(Keys.DEFAULT_DEVICE_NAME)
            } else {
                prefs[Keys.DEFAULT_DEVICE_ID] = id
                prefs[Keys.DEFAULT_DEVICE_NAME] = name
            }
        }
    }

    suspend fun setVideoQuality(quality: VideoQuality) {
        context.castDzDataStore.edit { it[Keys.VIDEO_QUALITY] = quality.name }
    }

    suspend fun setOnboardingCompleted(completed: Boolean) {
        context.castDzDataStore.edit { it[Keys.ONBOARDING_COMPLETED] = completed }
    }

    suspend fun setFakeDevicesEnabled(enabled: Boolean) {
        context.castDzDataStore.edit { it[Keys.FAKE_DEVICES_ENABLED] = enabled }
    }
}
