package com.castdz.app

import android.app.Application
import com.google.android.gms.cast.framework.CastContext
import dagger.hilt.android.HiltAndroidApp
import java.util.concurrent.Executors

@HiltAndroidApp
class CastDzApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Pre-warm Google Cast context asynchronously without blocking startup or crashing on devices without Play Services
        runCatching {
            CastContext.getSharedInstance(this, Executors.newSingleThreadExecutor())
        }
    }
}
