package com.castdz.app.ui.components

import android.content.Intent
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AddCircleOutline
import androidx.compose.material.icons.rounded.Cast
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.LinkOff
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Router
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.SignalCellularAlt
import androidx.compose.material.icons.rounded.Speaker
import androidx.compose.material.icons.rounded.Tv
import androidx.compose.material.icons.rounded.VpnKey
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.LottieConstants
import com.airbnb.lottie.compose.rememberLottieComposition
import com.castdz.app.R
import com.castdz.app.core.motion.rememberReduceMotionEnabled
import com.castdz.app.discovery.model.CastDevice
import com.castdz.app.discovery.model.CastProtocol
import com.castdz.app.discovery.model.DeviceConnectionState
import com.castdz.app.discovery.model.DeviceIconType
import com.castdz.app.discovery.model.DiagnosticCause
import com.castdz.app.discovery.model.DiscoveryDiagnostic
import com.castdz.app.ui.theme.AccentAmber
import com.castdz.app.ui.theme.AccentCyan
import com.castdz.app.ui.theme.AccentGreen
import com.castdz.app.ui.theme.AccentPink
import com.castdz.app.ui.theme.AccentViolet
import com.castdz.app.ui.theme.CosmicIndigo

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun DevicePickerSheet(
    devices: List<CastDevice>,
    isScanning: Boolean,
    diagnostics: List<DiscoveryDiagnostic>,
    onDismiss: () -> Unit,
    onSelectDevice: (CastDevice) -> Unit,
    onDisconnect: () -> Unit,
    onRefresh: () -> Unit,
    onAddManualDevice: (ip: String, name: String?, protocol: CastProtocol) -> Unit,
    onRequestDiscoveryPermission: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val context = LocalContext.current
    val haptics = LocalHapticFeedback.current
    val reduceMotion = rememberReduceMotionEnabled()

    var showManualDialog by remember { mutableStateOf(false) }
    var showLearnMoreDialog by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = if (MaterialTheme.colorScheme.background == Color(0xFF0A0830)) {
            CosmicIndigo.copy(alpha = 0.96f)
        } else {
            MaterialTheme.colorScheme.surface.copy(alpha = 0.97f)
        },
        shape = RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(bottom = 20.dp)
        ) {
            // Header with Lottie scanning animation
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isScanning) {
                        val composition by rememberLottieComposition(
                            LottieCompositionSpec.RawRes(R.raw.lottie_scanning)
                        )
                        LottieAnimation(
                            composition = composition,
                            iterations = if (reduceMotion) 1 else LottieConstants.IterateForever,
                            modifier = Modifier.size(38.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Column {
                        Text(
                            text = stringResource(R.string.sheet_select_device),
                            style = MaterialTheme.typography.titleLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = if (devices.isEmpty()) {
                                stringResource(R.string.sheet_scanning)
                            } else {
                                stringResource(R.string.sheet_devices_found, devices.size)
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                IconButton(onClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onRefresh()
                }) {
                    Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = stringResource(R.string.action_refresh),
                        tint = AccentCyan
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Live device list with spring entrance
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = false),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                itemsIndexed(devices, key = { _, d -> d.id }) { _, device ->
                    AnimatedVisibility(
                        visible = true,
                        enter = if (reduceMotion) fadeIn() else fadeIn() + slideInVertically(
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioMediumBouncy,
                                stiffness = Spring.StiffnessLow
                            ),
                            initialOffsetY = { it / 3 }
                        )
                    ) {
                        DeviceRowCard(
                            device = device,
                            onClick = {
                                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                onSelectDevice(device)
                            },
                            onDisconnect = onDisconnect
                        )
                    }
                }

                // Diagnostics after 8 seconds if no device found
                if (devices.isEmpty() && diagnostics.isNotEmpty()) {
                    item(key = "diagnostics_header") {
                        Text(
                            text = stringResource(R.string.diag_title),
                            style = MaterialTheme.typography.titleMedium,
                            color = AccentAmber,
                            modifier = Modifier.padding(top = 6.dp, bottom = 4.dp)
                        )
                    }
                    itemsIndexed(diagnostics, key = { _, diag -> diag.cause.name }) { _, diag ->
                        DiagnosticRowCard(
                            diagnostic = diag,
                            onFixClick = {
                                when (diag.cause) {
                                    DiagnosticCause.WIFI_OFF, DiagnosticCause.MOBILE_DATA_ONLY -> {
                                        runCatching {
                                            context.startActivity(
                                                Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                            )
                                        }
                                    }
                                    DiagnosticCause.PERMISSION_DENIED -> onRequestDiscoveryPermission()
                                    DiagnosticCause.VPN_ACTIVE -> {
                                        runCatching {
                                            context.startActivity(
                                                Intent(Settings.ACTION_VPN_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                            )
                                        }
                                    }
                                    DiagnosticCause.AP_ISOLATION -> showLearnMoreDialog = true
                                }
                            }
                        )
                    }
                }

                // "Add a device" row
                item(key = "add_device_row") {
                    GlassCard(
                        cornerRadius = 20.dp,
                        onClick = { showManualDialog = true }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon3D(
                                imageVector = Icons.Rounded.AddCircleOutline,
                                contentDescription = null,
                                gradientColors = listOf(AccentCyan, AccentViolet),
                                size = 40.dp,
                                iconSize = 20.dp,
                                enableParallax = false
                            )
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(R.string.sheet_add_device),
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = stringResource(R.string.sheet_add_device_sub),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // "Learn more" row
                item(key = "learn_more_row") {
                    GlassCard(
                        cornerRadius = 20.dp,
                        onClick = { showLearnMoreDialog = true }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon3D(
                                imageVector = Icons.Rounded.Info,
                                contentDescription = null,
                                gradientColors = listOf(AccentViolet, AccentPink),
                                size = 40.dp,
                                iconSize = 20.dp,
                                enableParallax = false
                            )
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = stringResource(R.string.sheet_learn_more),
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = stringResource(R.string.sheet_learn_more_sub),
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showManualDialog) {
        ManualIpDialog(
            onDismiss = { showManualDialog = false },
            onAdd = { ip, name, proto ->
                onAddManualDevice(ip, name, proto)
                showManualDialog = false
            }
        )
    }

    if (showLearnMoreDialog) {
        AlertDialog(
            onDismissRequest = { showLearnMoreDialog = false },
            title = { Text(stringResource(R.string.learn_more_title)) },
            text = { Text(stringResource(R.string.learn_more_body)) },
            confirmButton = {
                TextButton(onClick = { showLearnMoreDialog = false }) {
                    Text(stringResource(R.string.action_close))
                }
            }
        )
    }
}

@Composable
private fun DeviceRowCard(
    device: CastDevice,
    onClick: () -> Unit,
    onDisconnect: () -> Unit
) {
    val isConnected = device.state == DeviceConnectionState.CONNECTED
    val isConnecting = device.state == DeviceConnectionState.CONNECTING

    val iconVector = when (device.iconType) {
        DeviceIconType.CHROMECAST -> Icons.Rounded.Cast
        DeviceIconType.SPEAKER -> Icons.Rounded.Speaker
        else -> Icons.Rounded.Tv
    }
    val gradient = when (device.protocol) {
        CastProtocol.CAST -> listOf(AccentCyan, AccentViolet)
        CastProtocol.DLNA -> listOf(AccentViolet, AccentPink)
        CastProtocol.AIRPLAY -> listOf(AccentPink, AccentAmber)
        CastProtocol.ROKU -> listOf(AccentGreen, AccentCyan)
    }

    GlassCard(
        cornerRadius = 22.dp,
        borderColor = if (isConnected) AccentGreen.copy(alpha = 0.75f) else null,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon3D(
                imageVector = iconVector,
                contentDescription = null,
                gradientColors = gradient,
                size = 44.dp,
                iconSize = 22.dp,
                enableParallax = false
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = device.name,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = device.model,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    ProtocolChip(protocol = device.protocol)
                }
                Text(
                    text = when (device.state) {
                        DeviceConnectionState.CONNECTED -> stringResource(R.string.device_state_connected)
                        DeviceConnectionState.CONNECTING -> stringResource(R.string.device_state_connecting)
                        DeviceConnectionState.AVAILABLE -> stringResource(R.string.device_state_available)
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = when (device.state) {
                        DeviceConnectionState.CONNECTED -> AccentGreen
                        DeviceConnectionState.CONNECTING -> AccentAmber
                        DeviceConnectionState.AVAILABLE -> AccentCyan
                    }
                )
            }

            if (isConnected) {
                IconButton(onClick = onDisconnect) {
                    Icon(
                        imageVector = Icons.Rounded.LinkOff,
                        contentDescription = stringResource(R.string.action_disconnect),
                        tint = AccentPink
                    )
                }
            } else if (!isConnecting) {
                Icon(
                    imageVector = Icons.Rounded.CheckCircle,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.25f),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun ProtocolChip(protocol: CastProtocol) {
    val chipColor = when (protocol) {
        CastProtocol.CAST -> AccentCyan
        CastProtocol.DLNA -> AccentViolet
        CastProtocol.AIRPLAY -> AccentPink
        CastProtocol.ROKU -> AccentGreen
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(chipColor.copy(alpha = 0.18f))
            .border(0.75.dp, chipColor.copy(alpha = 0.55f), RoundedCornerShape(8.dp))
            .padding(horizontal = 7.dp, vertical = 2.dp)
    ) {
        Text(
            text = protocol.name,
            style = MaterialTheme.typography.labelSmall,
            color = chipColor,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun DiagnosticRowCard(
    diagnostic: DiscoveryDiagnostic,
    onFixClick: () -> Unit
) {
    val (icon, titleRes, descRes) = when (diagnostic.cause) {
        DiagnosticCause.WIFI_OFF -> Triple(Icons.Rounded.WifiOff, R.string.diag_wifi_off_title, R.string.diag_wifi_off_desc)
        DiagnosticCause.MOBILE_DATA_ONLY -> Triple(Icons.Rounded.SignalCellularAlt, R.string.diag_mobile_only_title, R.string.diag_mobile_only_desc)
        DiagnosticCause.PERMISSION_DENIED -> Triple(Icons.Rounded.Security, R.string.diag_perm_title, R.string.diag_perm_desc)
        DiagnosticCause.VPN_ACTIVE -> Triple(Icons.Rounded.VpnKey, R.string.diag_vpn_title, R.string.diag_vpn_desc)
        DiagnosticCause.AP_ISOLATION -> Triple(Icons.Rounded.Router, R.string.diag_ap_isolation_title, R.string.diag_ap_isolation_desc)
    }

    GlassCard(
        cornerRadius = 20.dp,
        borderColor = AccentAmber.copy(alpha = 0.55f)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = AccentAmber,
                modifier = Modifier.size(26.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(titleRes),
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = stringResource(descRes),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (diagnostic.canOneTapFix) {
                Spacer(modifier = Modifier.width(8.dp))
                OutlinedButton(onClick = onFixClick) {
                    Text(stringResource(R.string.action_fix_now))
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ManualIpDialog(
    onDismiss: () -> Unit,
    onAdd: (ip: String, name: String?, protocol: CastProtocol) -> Unit
) {
    var ip by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var protocol by remember { mutableStateOf(CastProtocol.DLNA) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.manual_ip_title)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = ip,
                    onValueChange = { ip = it },
                    label = { Text(stringResource(R.string.manual_ip_hint)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(stringResource(R.string.manual_name_hint)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = stringResource(R.string.manual_protocol_label),
                    style = MaterialTheme.typography.labelLarge
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CastProtocol.entries.forEach { proto ->
                        FilterChip(
                            selected = protocol == proto,
                            onClick = { protocol = proto },
                            label = { Text(proto.name) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onAdd(ip, name.ifBlank { null }, protocol) },
                enabled = ip.trim().count { it == '.' } == 3
            ) {
                Text(stringResource(R.string.action_add))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.action_cancel))
            }
        }
    )
}
