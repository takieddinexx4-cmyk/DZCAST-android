package com.castdz.app.discovery.scanner

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import com.castdz.app.core.network.WifiNetworkBinder
import com.castdz.app.discovery.model.CastDevice
import com.castdz.app.discovery.model.CastProtocol
import com.castdz.app.discovery.model.DeviceIconType
import com.castdz.app.discovery.parser.MdnsTxtParser
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Layer 2: Native Android NsdManager mDNS/DNS-SD discovery for:
 * - _googlecast._tcp.
 * - _airplay._tcp.
 * - _androidtvremote2._tcp.
 */
@Singleton
class MdnsScanner @Inject constructor(
    @ApplicationContext private val context: Context,
    private val wifiNetworkBinder: WifiNetworkBinder
) {
    private val serviceTypes = listOf(
        "_googlecast._tcp.",
        "_airplay._tcp.",
        "_androidtvremote2._tcp."
    )

    fun scan(): Flow<CastDevice> = callbackFlow {
        val nsdManager = context.getSystemService(Context.NSD_SERVICE) as? NsdManager
        if (nsdManager == null) {
            close()
            return@callbackFlow
        }

        val executor = Executors.newCachedThreadPool()
        val activeListeners = mutableListOf<NsdManager.DiscoveryListener>()
        val activeCallbacks = ConcurrentHashMap<String, NsdManager.ServiceInfoCallback>()

        for (serviceType in serviceTypes) {
            val listener = object : NsdManager.DiscoveryListener {
                override fun onStartDiscoveryFailed(type: String, errorCode: Int) {
                    runCatching { nsdManager.stopServiceDiscovery(this) }
                }

                override fun onStopDiscoveryFailed(type: String, errorCode: Int) = Unit
                override fun onDiscoveryStarted(type: String) = Unit
                override fun onDiscoveryStopped(type: String) = Unit
                override fun onServiceLost(serviceInfo: NsdServiceInfo) = Unit

                override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                    resolveService(nsdManager, serviceInfo, serviceType, executor, activeCallbacks) { device ->
                        trySend(device)
                    }
                }
            }

            runCatching {
                val wifiNet = wifiNetworkBinder.getWifiNetwork()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE && wifiNet != null) {
                    nsdManager.discoverServices(
                        serviceType,
                        NsdManager.PROTOCOL_DNS_SD,
                        wifiNet,
                        executor,
                        listener
                    )
                } else {
                    nsdManager.discoverServices(serviceType, NsdManager.PROTOCOL_DNS_SD, listener)
                }
                activeListeners.add(listener)
            }
        }

        awaitClose {
            activeListeners.forEach { listener ->
                runCatching { nsdManager.stopServiceDiscovery(listener) }
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                activeCallbacks.values.forEach { cb ->
                    runCatching { nsdManager.unregisterServiceInfoCallback(cb) }
                }
            }
            activeCallbacks.clear()
            executor.shutdownNow()
        }
    }

    private fun resolveService(
        nsdManager: NsdManager,
        serviceInfo: NsdServiceInfo,
        serviceType: String,
        executor: java.util.concurrent.Executor,
        activeCallbacks: ConcurrentHashMap<String, NsdManager.ServiceInfoCallback>,
        onResolved: (CastDevice) -> Unit
    ) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val key = "${serviceType}:${serviceInfo.serviceName}"
            if (activeCallbacks.containsKey(key)) return
            val callback = object : NsdManager.ServiceInfoCallback {
                override fun onServiceInfoCallbackRegistrationFailed(errorCode: Int) {
                    activeCallbacks.remove(key)
                }

                override fun onServiceUpdated(info: NsdServiceInfo) {
                    buildDevice(info, serviceType)?.let(onResolved)
                }

                override fun onServiceLost() = Unit
                override fun onServiceInfoCallbackUnregistered() {
                    activeCallbacks.remove(key)
                }
            }
            activeCallbacks[key] = callback
            runCatching {
                nsdManager.registerServiceInfoCallback(serviceInfo, executor, callback)
            }.onFailure {
                activeCallbacks.remove(key)
            }
        } else {
            @Suppress("DEPRECATION")
            runCatching {
                nsdManager.resolveService(
                    serviceInfo,
                    object : NsdManager.ResolveListener {
                        override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) = Unit
                        override fun onServiceResolved(info: NsdServiceInfo) {
                            buildDevice(info, serviceType)?.let(onResolved)
                        }
                    }
                )
            }
        }
    }

    private fun buildDevice(info: NsdServiceInfo, serviceType: String): CastDevice? {
        val ip = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            info.hostAddresses.firstOrNull { it is java.net.Inet4Address }?.hostAddress
                ?: info.hostAddresses.firstOrNull()?.hostAddress
        } else {
            @Suppress("DEPRECATION")
            info.host?.hostAddress
        } ?: return null

        val txt = MdnsTxtParser.parseAttributes(info.attributes)
        val protocol = when {
            serviceType.contains("airplay", ignoreCase = true) -> CastProtocol.AIRPLAY
            else -> CastProtocol.CAST
        }
        val manufacturer = when (protocol) {
            CastProtocol.AIRPLAY -> "Apple AirPlay"
            else -> "Google Cast"
        }
        val name = txt.friendlyName ?: info.serviceName.substringBefore("._")
        val model = txt.model ?: when {
            serviceType.contains("airplay", ignoreCase = true) -> "AirPlay Receiver"
            serviceType.contains("androidtv", ignoreCase = true) -> "Android TV"
            else -> "Cast Device"
        }
        val id = txt.uuid ?: "${protocol.name.lowercase()}:$ip"

        return CastDevice(
            id = id,
            name = name,
            model = model,
            manufacturer = manufacturer,
            protocol = protocol,
            ip = ip,
            port = info.port.takeIf { it > 0 } ?: 8009,
            iconType = txt.inferIconType(serviceType),
            lastSeen = System.currentTimeMillis()
        )
    }
}
