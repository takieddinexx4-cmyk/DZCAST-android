package com.castdz.app.casting.server

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.castdz.app.core.network.WifiNetworkBinder
import dagger.hilt.android.qualifiers.ApplicationContext
import fi.iki.elonen.NanoHTTPD
import java.io.InputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Embedded NanoHTTPD server with HTTP Range (206 Partial Content) support
 * for streaming local videos, photos, audio, and subtitle files over Wi-Fi.
 */
@Singleton
class LocalMediaServer @Inject constructor(
    @ApplicationContext private val context: Context,
    private val wifiNetworkBinder: WifiNetworkBinder
) {
    private data class HostedFile(
        val uri: Uri,
        val mimeType: String,
        val sizeBytes: Long
    )

    private val hostedFiles = ConcurrentHashMap<String, HostedFile>()
    private var server: MediaNanoServer? = null
    private var activePort: Int = DEFAULT_PORT

    @Synchronized
    fun ensureStarted(): Int {
        if (server?.isAlive == true) return activePort
        val portsToTry = listOf(DEFAULT_PORT, 8890, 8891, 8892, 0)
        for (port in portsToTry) {
            val candidate = MediaNanoServer(port)
            val started = runCatching {
                candidate.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
                true
            }.getOrDefault(false)
            if (started) {
                server = candidate
                activePort = candidate.listeningPort
                return activePort
            }
        }
        return activePort
    }

    @Synchronized
    fun stop() {
        runCatching { server?.stop() }
        server = null
        hostedFiles.clear()
    }

    /**
     * Registers a local content:// Uri and returns its LAN HTTP URL
     * (e.g., http://192.168.1.25:8889/media/<token>).
     */
    fun hostContentUri(uri: Uri, mimeType: String): String? {
        val port = ensureStarted()
        val ip = wifiNetworkBinder.resolveLocalIpv4() ?: return null
        val size = queryFileSize(uri)
        val token = UUID.randomUUID().toString().replace("-", "").take(16)
        hostedFiles[token] = HostedFile(uri = uri, mimeType = mimeType, sizeBytes = size)
        return "http://$ip:$port/media/$token"
    }

    private fun queryFileSize(uri: Uri): Long {
        return runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getLong(0) else -1L
            } ?: -1L
        }.getOrDefault(-1L)
    }

    private inner class MediaNanoServer(port: Int) : NanoHTTPD(port) {
        override fun serve(session: IHTTPSession): Response {
            val path = session.uri.trim('/')
            if (!path.startsWith("media/")) {
                return newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "Not found")
            }
            val token = path.removePrefix("media/").substringBefore('/')
            val hosted = hostedFiles[token]
                ?: return newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "Media expired")

            val totalLength = hosted.sizeBytes.takeIf { it > 0 } ?: runCatching {
                context.contentResolver.openAssetFileDescriptor(hosted.uri, "r")?.use { it.length } ?: -1L
            }.getOrDefault(-1L)

            val rangeHeader = session.headers["range"]
            if (rangeHeader != null && rangeHeader.startsWith("bytes=") && totalLength > 0) {
                val rangeSpec = rangeHeader.removePrefix("bytes=").substringBefore(',')
                val parts = rangeSpec.split('-')
                val start = parts.getOrNull(0)?.toLongOrNull() ?: 0L
                val end = parts.getOrNull(1)?.toLongOrNull() ?: (totalLength - 1)
                val safeStart = start.coerceIn(0L, totalLength - 1)
                val safeEnd = end.coerceIn(safeStart, totalLength - 1)
                val contentLength = safeEnd - safeStart + 1

                val inputStream = openStreamAtOffset(hosted.uri, safeStart)
                    ?: return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, MIME_PLAINTEXT, "Cannot open file")

                return newFixedLengthResponse(
                    Response.Status.PARTIAL_CONTENT,
                    hosted.mimeType,
                    inputStream,
                    contentLength
                ).apply {
                    addHeader("Accept-Ranges", "bytes")
                    addHeader("Content-Range", "bytes $safeStart-$safeEnd/$totalLength")
                    addHeader("Content-Length", contentLength.toString())
                    addHeader("Access-Control-Allow-Origin", "*")
                }
            }

            val inputStream = context.contentResolver.openInputStream(hosted.uri)
                ?: return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, MIME_PLAINTEXT, "Cannot open file")

            val response = if (totalLength > 0) {
                newFixedLengthResponse(Response.Status.OK, hosted.mimeType, inputStream, totalLength)
            } else {
                newChunkedResponse(Response.Status.OK, hosted.mimeType, inputStream)
            }
            return response.apply {
                addHeader("Accept-Ranges", "bytes")
                addHeader("Access-Control-Allow-Origin", "*")
            }
        }

        private fun openStreamAtOffset(uri: Uri, offset: Long): InputStream? {
            return runCatching {
                val stream = context.contentResolver.openInputStream(uri) ?: return null
                var remaining = offset
                while (remaining > 0) {
                    val skipped = stream.skip(remaining)
                    if (skipped <= 0) break
                    remaining -= skipped
                }
                stream
            }.getOrNull()
        }
    }

    companion object {
        private const val DEFAULT_PORT = 8889
    }
}
