package com.castdz.app.casting.server

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.castdz.app.core.network.WifiNetworkBinder
import dagger.hilt.android.qualifiers.ApplicationContext
import fi.iki.elonen.NanoHTTPD
import org.json.JSONObject
import java.io.InputStream
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.random.Random

data class WebReceiverPlaybackPayload(
    val mediaUrl: String? = null,
    val title: String = "CastDZ",
    val mimeType: String = "video/mp4",
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val seekToken: Int = 0,
    val volume: Float = 0.8f,
    val subtitleUrl: String? = null,
    val subtitlesEnabled: Boolean = false
)

data class WebReceiverSessionInfo(
    val url: String? = null,
    val pairingCode: String = "",
    val isRunning: Boolean = false,
    val isPaired: Boolean = false,
    val pairedClientIp: String? = null
)

/**
 * Embedded NanoHTTPD server with:
 * 1. HTTP Range (206 Partial Content) streaming for local videos, photos, audio, and subtitles.
 * 2. Built-in Local Web Receiver (http://<phone-ip>:8889) with 4-digit pairing code so ANY
 *    Smart TV browser (Samsung, LG, Hisense, Android TV, PC) can connect in seconds.
 */
@Singleton
class LocalMediaServer @Inject constructor(
    @ApplicationContext private val context: Context,
    private val wifiNetworkBinder: WifiNetworkBinder
) {
    private data class HostedFile(
        val uri: Uri,
        val mimeType: String,
        val sizeBytes: Long
    )

    private val hostedFiles = ConcurrentHashMap<String, HostedFile>()
    private var server: MediaNanoServer? = null
    private var activePort: Int = DEFAULT_PORT

    @Volatile
    private var pairingCode: String = generateCode()

    @Volatile
    private var pairedClientIp: String? = null

    private val webPlaybackState = AtomicReference(WebReceiverPlaybackPayload())
    private val seekCounter = AtomicInteger(0)

    @Volatile
    private var onReceiverPairedListener: ((clientIp: String) -> Unit)? = null

    fun setOnReceiverPairedListener(listener: ((clientIp: String) -> Unit)?) {
        onReceiverPairedListener = listener
    }

    @Synchronized
    fun ensureStarted(): Int {
        if (server?.isAlive == true) return activePort
        val portsToTry = listOf(DEFAULT_PORT, 8890, 8891, 8892, 0)
        for (port in portsToTry) {
            val candidate = MediaNanoServer(port)
            val started = runCatching {
                candidate.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
                true
            }.getOrDefault(false)
            if (started) {
                server = candidate
                activePort = candidate.listeningPort
                return activePort
            }
        }
        return activePort
    }

    fun startWebReceiver(regenerateCode: Boolean = false): WebReceiverSessionInfo {
        val port = ensureStarted()
        if (regenerateCode || pairingCode.isBlank()) {
            pairingCode = generateCode()
            pairedClientIp = null
        }
        val ip = wifiNetworkBinder.resolveLocalIpv4()
        val url = ip?.let { "http://$it:$port" }
        return WebReceiverSessionInfo(
            url = url,
            pairingCode = pairingCode,
            isRunning = server?.isAlive == true,
            isPaired = pairedClientIp != null,
            pairedClientIp = pairedClientIp
        )
    }

    fun getWebReceiverInfo(): WebReceiverSessionInfo {
        val ip = wifiNetworkBinder.resolveLocalIpv4()
        val running = server?.isAlive == true
        return WebReceiverSessionInfo(
            url = if (ip != null && running) "http://$ip:$activePort" else null,
            pairingCode = pairingCode,
            isRunning = running,
            isPaired = pairedClientIp != null,
            pairedClientIp = pairedClientIp
        )
    }

    fun updateWebReceiverPlayback(
        mediaUrl: String? = webPlaybackState.get().mediaUrl,
        title: String = webPlaybackState.get().title,
        mimeType: String = webPlaybackState.get().mimeType,
        isPlaying: Boolean = webPlaybackState.get().isPlaying,
        positionMs: Long = webPlaybackState.get().positionMs,
        triggerSeek: Boolean = false,
        volume: Float = webPlaybackState.get().volume,
        subtitleUrl: String? = webPlaybackState.get().subtitleUrl,
        subtitlesEnabled: Boolean = webPlaybackState.get().subtitlesEnabled
    ) {
        val token = if (triggerSeek) seekCounter.incrementAndGet() else webPlaybackState.get().seekToken
        webPlaybackState.set(
            WebReceiverPlaybackPayload(
                mediaUrl = mediaUrl,
                title = title,
                mimeType = mimeType,
                isPlaying = isPlaying,
                positionMs = positionMs,
                seekToken = token,
                volume = volume,
                subtitleUrl = subtitleUrl,
                subtitlesEnabled = subtitlesEnabled
            )
        )
    }

    fun clearWebReceiverPlayback() {
        webPlaybackState.set(WebReceiverPlaybackPayload())
    }

    @Synchronized
    fun stop() {
        runCatching { server?.stop() }
        server = null
        hostedFiles.clear()
        pairedClientIp = null
    }

    fun hostContentUri(uri: Uri, mimeType: String): String? {
        val port = ensureStarted()
        val ip = wifiNetworkBinder.resolveLocalIpv4() ?: return null
        val size = queryFileSize(uri)
        val token = UUID.randomUUID().toString().replace("-", "").take(16)
        hostedFiles[token] = HostedFile(uri = uri, mimeType = mimeType, sizeBytes = size)
        return "http://$ip:$port/media/$token"
    }

    private fun queryFileSize(uri: Uri): Long {
        return runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getLong(0) else -1L
            } ?: -1L
        }.getOrDefault(-1L)
    }

    private fun generateCode(): String = Random.nextInt(1000, 9999).toString()

    private inner class MediaNanoServer(port: Int) : NanoHTTPD(port) {
        override fun serve(session: IHTTPSession): Response {
            val path = session.uri.trim('/')

            return when {
                path.isEmpty() || path == "tv" || path == "receiver" -> {
                    newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", buildReceiverHtml())
                }
                path == "api/pair" -> handlePair(session)
                path == "api/state" -> handleState(session)
                path.startsWith("media/") -> handleMedia(session, path)
                else -> newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "Not found")
            }
        }

        private fun handlePair(session: IHTTPSession): Response {
            val submitted = session.parameters["code"]?.firstOrNull()?.trim().orEmpty()
            val ok = submitted.equals(pairingCode, ignoreCase = true)
            if (ok) {
                val remoteIp = session.remoteIpAddress ?: "TV"
                pairedClientIp = remoteIp
                onReceiverPairedListener?.invoke(remoteIp)
            }
            val json = JSONObject().apply {
                put("paired", ok)
                put("code", if (ok) pairingCode else "")
            }
            return newFixedLengthResponse(Response.Status.OK, "application/json", json.toString()).apply {
                addHeader("Access-Control-Allow-Origin", "*")
            }
        }

        private fun handleState(session: IHTTPSession): Response {
            val submitted = session.parameters["code"]?.firstOrNull()?.trim().orEmpty()
            if (!submitted.equals(pairingCode, ignoreCase = true)) {
                return newFixedLengthResponse(Response.Status.FORBIDDEN, "application/json", """{"error":"invalid_code"}""")
            }
            val st = webPlaybackState.get()
            val json = JSONObject().apply {
                put("mediaUrl", st.mediaUrl ?: JSONObject.NULL)
                put("title", st.title)
                put("mimeType", st.mimeType)
                put("isPlaying", st.isPlaying)
                put("positionMs", st.positionMs)
                put("seekToken", st.seekToken)
                put("volume", st.volume.toDouble())
                put("subtitleUrl", st.subtitleUrl ?: JSONObject.NULL)
                put("subtitlesEnabled", st.subtitlesEnabled)
            }
            return newFixedLengthResponse(Response.Status.OK, "application/json", json.toString()).apply {
                addHeader("Access-Control-Allow-Origin", "*")
                addHeader("Cache-Control", "no-store")
            }
        }

        private fun handleMedia(session: IHTTPSession, path: String): Response {
            val token = path.removePrefix("media/").substringBefore('/')
            val hosted = hostedFiles[token]
                ?: return newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "Media expired")

            val totalLength = hosted.sizeBytes.takeIf { it > 0 } ?: runCatching {
                context.contentResolver.openAssetFileDescriptor(hosted.uri, "r")?.use { it.length } ?: -1L
            }.getOrDefault(-1L)

            val rangeHeader = session.headers["range"]
            if (rangeHeader != null && rangeHeader.startsWith("bytes=") && totalLength > 0) {
                val rangeSpec = rangeHeader.removePrefix("bytes=").substringBefore(',')
                val parts = rangeSpec.split('-')
                val start = parts.getOrNull(0)?.toLongOrNull() ?: 0L
                val end = parts.getOrNull(1)?.toLongOrNull() ?: (totalLength - 1)
                val safeStart = start.coerceIn(0L, totalLength - 1)
                val safeEnd = end.coerceIn(safeStart, totalLength - 1)
                val contentLength = safeEnd - safeStart + 1

                val inputStream = openStreamAtOffset(hosted.uri, safeStart)
                    ?: return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, MIME_PLAINTEXT, "Cannot open file")

                return newFixedLengthResponse(
                    Response.Status.PARTIAL_CONTENT,
                    hosted.mimeType,
                    inputStream,
                    contentLength
                ).apply {
                    addHeader("Accept-Ranges", "bytes")
                    addHeader("Content-Range", "bytes $safeStart-$safeEnd/$totalLength")
                    addHeader("Content-Length", contentLength.toString())
                    addHeader("Access-Control-Allow-Origin", "*")
                }
            }

            val inputStream = context.contentResolver.openInputStream(hosted.uri)
                ?: return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, MIME_PLAINTEXT, "Cannot open file")

            val response = if (totalLength > 0) {
                newFixedLengthResponse(Response.Status.OK, hosted.mimeType, inputStream, totalLength)
            } else {
                newChunkedResponse(Response.Status.OK, hosted.mimeType, inputStream)
            }
            return response.apply {
                addHeader("Accept-Ranges", "bytes")
                addHeader("Access-Control-Allow-Origin", "*")
            }
        }

        private fun openStreamAtOffset(uri: Uri, offset: Long): InputStream? {
            return runCatching {
                val stream = context.contentResolver.openInputStream(uri) ?: return null
                var remaining = offset
                while (remaining > 0) {
                    val skipped = stream.skip(remaining)
                    if (skipped <= 0) break
                    remaining -= skipped
                }
                stream
            }.getOrNull()
        }

        private fun buildReceiverHtml(): String = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>CastDZ Web Receiver</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:system-ui,-apple-system,sans-serif;background:linear-gradient(135deg,#0A0830,#1A0F4D,#07203A);color:#F6F8FF;min-height:100vh;display:flex;align-items:center;justify-content:center;overflow:hidden}
  .card{background:rgba(255,255,255,0.09);border:1px solid rgba(255,255,255,0.22);backdrop-filter:blur(20px);border-radius:28px;padding:36px 40px;max-width:460px;width:92%;text-align:center;box-shadow:0 24px 60px rgba(0,0,0,0.45)}
  h1{font-size:2rem;background:linear-gradient(90deg,#00E5FF,#7C4DFF,#FF2BD6);-webkit-background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:8px}
  p{color:#B4BDDD;margin-bottom:22px;line-height:1.5}
  input{width:100%;padding:16px;font-size:1.8rem;text-align:center;letter-spacing:8px;border-radius:16px;border:1px solid rgba(0,229,255,0.5);background:rgba(10,8,48,0.65);color:#fff;outline:none;margin-bottom:16px}
  button{width:100%;padding:15px;border:none;border-radius:16px;font-size:1.1rem;font-weight:700;background:linear-gradient(90deg,#00E5FF,#7C4DFF);color:#0A0830;cursor:pointer}
  #status{margin-top:14px;color:#00E5FF;font-size:0.95rem}
  #stage{position:fixed;inset:0;background:#000;display:none;align-items:center;justify-content:center}
  video,img{width:100%;height:100%;object-fit:contain}
  #overlay{position:fixed;top:20px;left:24px;background:rgba(10,8,48,0.72);padding:10px 18px;border-radius:14px;border:1px solid rgba(0,229,255,0.4);font-size:1rem;display:none}
</style>
</head>
<body>
<div class="card" id="pairBox">
  <h1>CastDZ Receiver</h1>
  <p>Enter the 4-digit code shown on your phone to start casting instantly.</p>
  <input id="codeInput" type="text" maxlength="6" placeholder="0000" autofocus/>
  <button onclick="pair()">Connect TV</button>
  <div id="status"></div>
</div>
<div id="stage">
  <video id="videoPlayer" controls autoplay playsinline></video>
  <img id="imgPlayer" style="display:none"/>
  <div id="overlay"></div>
</div>
<script>
let activeCode = new URLSearchParams(location.search).get('code') || '';
let lastUrl = null;
let lastSeekToken = -1;
const video = document.getElementById('videoPlayer');
const img = document.getElementById('imgPlayer');
const stage = document.getElementById('stage');
const pairBox = document.getElementById('pairBox');
const overlay = document.getElementById('overlay');

if (activeCode) {
  document.getElementById('codeInput').value = activeCode;
  pair();
}

async function pair() {
  const code = document.getElementById('codeInput').value.trim();
  const res = await fetch('/api/pair?code=' + encodeURIComponent(code));
  const data = await res.json();
  if (data.paired) {
    activeCode = code;
    document.getElementById('status').textContent = 'Connected! Waiting for media from CastDZ...';
    setInterval(pollState, 1000);
  } else {
    document.getElementById('status').textContent = 'Invalid code. Check your CastDZ app.';
  }
}

async function pollState() {
  try {
    const res = await fetch('/api/state?code=' + encodeURIComponent(activeCode));
    if (!res.ok) return;
    const s = await res.json();
    if (!s.mediaUrl) {
      stage.style.display = 'none';
      pairBox.style.display = 'block';
      return;
    }
    pairBox.style.display = 'none';
    stage.style.display = 'flex';
    overlay.textContent = s.title || 'CastDZ';
    overlay.style.display = 'block';

    if (s.mimeType && s.mimeType.startsWith('image/')) {
      video.pause();
      video.style.display = 'none';
      img.style.display = 'block';
      if (img.src !== s.mediaUrl) img.src = s.mediaUrl;
      return;
    }

    img.style.display = 'none';
    video.style.display = 'block';
    if (lastUrl !== s.mediaUrl) {
      lastUrl = s.mediaUrl;
      video.src = s.mediaUrl;
      video.load();
    }
    if (s.seekToken !== lastSeekToken) {
      lastSeekToken = s.seekToken;
      if (!isNaN(s.positionMs)) video.currentTime = s.positionMs / 1000;
    }
    video.volume = Math.max(0, Math.min(1, s.volume || 0.8));
    if (s.isPlaying && video.paused) { video.play().catch(()=>{}); }
    if (!s.isPlaying && !video.paused) { video.pause(); }
  } catch (e) {}
}
</script>
</body>
</html>
        """.trimIndent()
    }

    companion object {
        private const val DEFAULT_PORT = 8889
    }
}
