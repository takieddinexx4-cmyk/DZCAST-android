package com.castdz.app.data.repository

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

enum class LocalMediaType { VIDEO, PHOTO, AUDIO }

data class LocalMediaItem(
    val id: Long,
    val title: String,
    val uri: Uri,
    val mimeType: String,
    val sizeBytes: Long,
    val durationMs: Long,
    val dateAddedSeconds: Long,
    val type: LocalMediaType
)

@Singleton
class MediaLibraryRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    suspend fun loadMedia(type: LocalMediaType): List<LocalMediaItem> = withContext(Dispatchers.IO) {
        when (type) {
            LocalMediaType.VIDEO -> queryVideos()
            LocalMediaType.PHOTO -> queryPhotos()
            LocalMediaType.AUDIO -> queryAudio()
        }
    }

    private fun queryVideos(): List<LocalMediaItem> {
        val result = mutableListOf<LocalMediaItem>()
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.MIME_TYPE,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.DATE_ADDED
        )
        runCatching {
            context.contentResolver.query(
                collection,
                projection,
                null,
                null,
                "${MediaStore.Video.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    result.add(
                        LocalMediaItem(
                            id = id,
                            title = cursor.getString(nameCol) ?: "Video $id",
                            uri = ContentUris.withAppendedId(collection, id),
                            mimeType = cursor.getString(mimeCol) ?: "video/mp4",
                            sizeBytes = cursor.getLong(sizeCol),
                            durationMs = cursor.getLong(durCol),
                            dateAddedSeconds = cursor.getLong(dateCol),
                            type = LocalMediaType.VIDEO
                        )
                    )
                }
            }
        }
        return result
    }

    private fun queryPhotos(): List<LocalMediaItem> {
        val result = mutableListOf<LocalMediaItem>()
        val collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.MIME_TYPE,
            MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.DATE_ADDED
        )
        runCatching {
            context.contentResolver.query(
                collection,
                projection,
                null,
                null,
                "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    result.add(
                        LocalMediaItem(
                            id = id,
                            title = cursor.getString(nameCol) ?: "Photo $id",
                            uri = ContentUris.withAppendedId(collection, id),
                            mimeType = cursor.getString(mimeCol) ?: "image/jpeg",
                            sizeBytes = cursor.getLong(sizeCol),
                            durationMs = 0L,
                            dateAddedSeconds = cursor.getLong(dateCol),
                            type = LocalMediaType.PHOTO
                        )
                    )
                }
            }
        }
        return result
    }

    private fun queryAudio(): List<LocalMediaItem> {
        val result = mutableListOf<LocalMediaItem>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_ADDED
        )
        runCatching {
            context.contentResolver.query(
                collection,
                projection,
                "${MediaStore.Audio.Media.IS_MUSIC} != 0",
                null,
                "${MediaStore.Audio.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    result.add(
                        LocalMediaItem(
                            id = id,
                            title = cursor.getString(nameCol) ?: "Audio $id",
                            uri = ContentUris.withAppendedId(collection, id),
                            mimeType = cursor.getString(mimeCol) ?: "audio/mpeg",
                            sizeBytes = cursor.getLong(sizeCol),
                            durationMs = cursor.getLong(durCol),
                            dateAddedSeconds = cursor.getLong(dateCol),
                            type = LocalMediaType.AUDIO
                        )
                    )
                }
            }
        }
        return result
    }
}
