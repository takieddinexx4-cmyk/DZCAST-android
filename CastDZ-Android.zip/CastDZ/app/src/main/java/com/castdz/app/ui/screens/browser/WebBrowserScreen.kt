package com.castdz.app.ui.screens.browser

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.Cast
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.castdz.app.R
import com.castdz.app.ui.components.GlassCard
import com.castdz.app.ui.theme.AccentCyan
import com.castdz.app.ui.theme.AccentPink
import com.castdz.app.ui.theme.AccentViolet

class VideoDetectionJsBridge(
    private val onSourceFound: (String) -> Unit
) {
    @JavascriptInterface
    fun onVideoUrl(url: String?) {
        if (!url.isNullOrBlank()) {
            onSourceFound(url)
        }
    }
}

/**
 * Continuous in-page video detector:
 * - Hooks HTMLMediaElement.prototype.play() so pressing play immediately captures the stream URL
 * - Hooks fetch() and XMLHttpRequest.open() to catch .m3u8 / .mp4 / .mpd / .webm streams loaded via JS
 * - Scans DOM <video> and <source> elements immediately and every 2 seconds
 */
private const val VIDEO_HOOK_JS = """
(function() {
  if (window.__castDzHooked) {
    if (window.__castDzScanNow) window.__castDzScanNow();
    return;
  }
  window.__castDzHooked = true;
  var reported = new Set();

  function report(url) {
    try {
      if (!url || typeof url !== 'string') return;
      var abs = new URL(url, location.href).href;
      if (!abs.startsWith('http') || reported.has(abs)) return;
      reported.add(abs);
      if (window.CastDzBridge) { window.CastDzBridge.onVideoUrl(abs); }
    } catch (e) {}
  }

  function scanDom() {
    try {
      document.querySelectorAll('video, source').forEach(function(el) {
        if (el.currentSrc) report(el.currentSrc);
        if (el.src) report(el.src);
        var attr = el.getAttribute && el.getAttribute('src');
        if (attr) report(attr);
      });
    } catch (e) {}
  }
  window.__castDzScanNow = scanDom;

  // Hook <video>.play()
  try {
    var origPlay = HTMLMediaElement.prototype.play;
    HTMLMediaElement.prototype.play = function() {
      if (this.currentSrc) report(this.currentSrc);
      if (this.src) report(this.src);
      scanDom();
      return origPlay.apply(this, arguments);
    };
  } catch (e) {}

  // Hook fetch()
  try {
    var origFetch = window.fetch;
    window.fetch = function(input) {
      try {
        var u = (typeof input === 'string') ? input : (input && input.url);
        if (u) report(u);
      } catch (e) {}
      return origFetch.apply(this, arguments);
    };
  } catch (e) {}

  // Hook XMLHttpRequest.open()
  try {
    var origOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(method, url) {
      if (url) report(url);
      return origOpen.apply(this, arguments);
    };
  } catch (e) {}

  scanDom();
  setInterval(scanDom, 2000);
})();
"""

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebBrowserScreen(
    initialUrl: String? = null,
    onOpenDevicePicker: () -> Unit,
    viewModel: WebBrowserViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val bookmarks by viewModel.bookmarks.collectAsStateWithLifecycle()
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var showDetectedSheet by remember { mutableStateOf(false) }

    val isBookmarked = bookmarks.any { it.url == state.activeTab.url }

    LaunchedEffect(initialUrl) {
        if (!initialUrl.isNullOrBlank()) {
            val target = viewModel.navigateTo(initialUrl)
            webViewRef?.loadUrl(target)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            // URL bar + controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { webViewRef?.takeIf { it.canGoBack() }?.goBack() }) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = stringResource(R.string.browser_back_cd)
                    )
                }
                IconButton(onClick = { webViewRef?.takeIf { it.canGoForward() }?.goForward() }) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                        contentDescription = stringResource(R.string.browser_forward_cd)
                    )
                }
                OutlinedTextField(
                    value = state.urlInput,
                    onValueChange = viewModel::updateUrlInput,
                    placeholder = { Text(stringResource(R.string.browser_url_hint)) },
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(
                        onGo = {
                            val target = viewModel.navigateTo(state.urlInput)
                            webViewRef?.loadUrl(target)
                        }
                    ),
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { viewModel.toggleBookmark() }) {
                    Icon(
                        imageVector = if (isBookmarked) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
                        contentDescription = stringResource(R.string.browser_bookmark_cd),
                        tint = if (isBookmarked) AccentPink else MaterialTheme.colorScheme.onSurface
                    )
                }
                IconButton(onClick = {
                    webViewRef?.evaluateJavascript(VIDEO_HOOK_JS, null)
                    webViewRef?.reload()
                }) {
                    Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = stringResource(R.string.browser_reload_cd)
                    )
                }
            }

            // Tabs strip
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                itemsIndexed(state.tabs, key = { _, tab -> tab.id }) { idx, tab ->
                    FilterChip(
                        selected = idx == state.activeTabIndex,
                        onClick = {
                            viewModel.selectTab(idx)
                            webViewRef?.loadUrl(tab.url)
                        },
                        label = {
                            Text(
                                text = tab.title.take(18),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        trailingIcon = if (state.tabs.size > 1) {
                            {
                                IconButton(
                                    onClick = { viewModel.closeTab(idx) },
                                    modifier = Modifier.size(18.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Close,
                                        contentDescription = stringResource(R.string.action_close),
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        } else null
                    )
                }
                item(key = "new_tab_btn") {
                    IconButton(onClick = {
                        viewModel.addTab()
                        webViewRef?.loadUrl("https://www.google.com")
                    }) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = stringResource(R.string.browser_new_tab),
                            tint = AccentCyan
                        )
                    }
                }
            }

            if (state.isLoading) {
                LinearProgressIndicator(
                    modifier = Modifier.fillMaxWidth(),
                    color = AccentCyan,
                    trackColor = AccentViolet.copy(alpha = 0.2f)
                )
            }

            // WebView container
            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                        settings.userAgentString =
                            "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
                        addJavascriptInterface(
                            VideoDetectionJsBridge { detectedUrl ->
                                post {
                                    viewModel.onVideoDetected(detectedUrl, title)
                                }
                            },
                            "CastDzBridge"
                        )
                        webChromeClient = WebChromeClient()
                        webViewClient = object : WebViewClient() {
                            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                url?.let { viewModel.onPageStarted(it) }
                                view?.evaluateJavascript(VIDEO_HOOK_JS, null)
                            }

                            override fun onPageFinished(view: WebView?, url: String?) {
                                url?.let { viewModel.onPageFinished(it, view?.title) }
                                view?.evaluateJavascript(VIDEO_HOOK_JS, null)
                            }

                            override fun shouldInterceptRequest(
                                view: WebView?,
                                request: WebResourceRequest?
                            ): WebResourceResponse? {
                                val reqUrl = request?.url?.toString()
                                if (reqUrl != null && WebBrowserViewModel.inferMimeType(reqUrl.lowercase()) != null) {
                                    view?.post { viewModel.onVideoDetected(reqUrl, view.title) }
                                }
                                return super.shouldInterceptRequest(view, request)
                            }
                        }
                        loadUrl(state.activeTab.url)
                        webViewRef = this
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(top = 4.dp)
                    .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            )
        }

        // Floating "Cast this video" pill
        AnimatedVisibility(
            visible = state.detectedVideos.isNotEmpty(),
            enter = scaleIn(),
            exit = scaleOut(),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = 92.dp)
        ) {
            ExtendedFloatingActionButton(
                onClick = { showDetectedSheet = true },
                containerColor = AccentCyan,
                contentColor = Color(0xFF0A0830),
                icon = { Icon(Icons.Rounded.Cast, contentDescription = null) },
                text = { Text(stringResource(R.string.browser_cast_pill, state.detectedVideos.size)) }
            )
        }
    }

    if (showDetectedSheet) {
        ModalBottomSheet(onDismissRequest = { showDetectedSheet = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Text(
                    text = stringResource(R.string.browser_detected_title),
                    style = MaterialTheme.typography.titleLarge
                )
                Text(
                    text = stringResource(R.string.browser_drm_note),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 28.dp)
                ) {
                    items(state.detectedVideos, key = { it.url }) { video ->
                        GlassCard(
                            cornerRadius = 18.dp,
                            onClick = {
                                showDetectedSheet = false
                                viewModel.castDetectedVideo(video, onOpenDevicePicker)
                            }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = video.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${video.mimeType} • ${video.url}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Icon(
                                    imageVector = Icons.Rounded.Cast,
                                    contentDescription = stringResource(R.string.action_cast),
                                    tint = AccentCyan
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
