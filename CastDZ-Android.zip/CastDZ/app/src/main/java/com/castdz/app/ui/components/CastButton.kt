package com.castdz.app.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Cast
import androidx.compose.material.icons.rounded.CastConnected
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.castdz.app.R
import com.castdz.app.core.motion.rememberReduceMotionEnabled
import com.castdz.app.ui.theme.AccentCyan
import com.castdz.app.ui.theme.AccentGreen
import com.castdz.app.ui.theme.AccentPink
import com.castdz.app.ui.theme.AccentViolet

@Composable
fun CastTopBarButton(
    nearbyCount: Int,
    isConnecting: Boolean,
    connectedDeviceName: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val haptics = LocalHapticFeedback.current
    val reduceMotion = rememberReduceMotionEnabled()
    val isConnected = connectedDeviceName != null

    val pulseScale = if (isConnecting && !reduceMotion) {
        val transition = rememberInfiniteTransition(label = "castPulse")
        val scale by transition.animateFloat(
            initialValue = 0.92f,
            targetValue = 1.12f,
            animationSpec = infiniteRepeatable(
                animation = tween(650),
                repeatMode = RepeatMode.Reverse
            ),
            label = "castPulseScale"
        )
        scale
    } else {
        1f
    }

    val cdText = if (isConnected) {
        stringResource(R.string.cast_connected_cd, connectedDeviceName!!)
    } else {
        stringResource(R.string.cast_button_cd)
    }

    Box(
        modifier = modifier
            .size(44.dp)
            .semantics { contentDescription = cdText },
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .scale(pulseScale)
                .clip(CircleShape)
                .background(
                    if (isConnected) {
                        Brush.linearGradient(listOf(AccentCyan, AccentViolet))
                    } else {
                        Brush.linearGradient(
                            listOf(
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                            )
                        )
                    }
                )
                .border(
                    width = 1.dp,
                    color = if (isConnected) AccentCyan else Color.White.copy(alpha = 0.25f),
                    shape = CircleShape
                )
                .clickable(role = Role.Button) {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    onClick()
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isConnected) Icons.Rounded.CastConnected else Icons.Rounded.Cast,
                contentDescription = null,
                tint = if (isConnected) Color.White else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(22.dp)
            )
        }

        // Badge when screens are detected nearby (or green dot when connected)
        if (isConnected) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = (-2).dp, y = 2.dp)
                    .size(11.dp)
                    .clip(CircleShape)
                    .background(AccentGreen)
                    .border(1.5.dp, MaterialTheme.colorScheme.background, CircleShape)
            )
        } else if (nearbyCount > 0) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 1.dp, y = (-1).dp)
                    .size(18.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(AccentPink, AccentViolet)))
                    .border(1.dp, Color.White.copy(alpha = 0.7f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (nearbyCount > 9) "9+" else nearbyCount.toString(),
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 10.sp
                )
            }
        }
    }
}
