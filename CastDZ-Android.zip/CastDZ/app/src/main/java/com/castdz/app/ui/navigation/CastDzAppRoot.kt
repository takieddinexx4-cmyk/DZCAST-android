package com.castdz.app.ui.navigation

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CollectionsBookmark
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.PermMedia
import androidx.compose.material.icons.rounded.ScreenShare
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.castdz.app.R
import com.castdz.app.core.permissions.DiscoveryPermissionHelper
import com.castdz.app.ui.components.CastTopBarButton
import com.castdz.app.ui.components.DevicePickerSheet
import com.castdz.app.ui.components.ExpandedPlayerSheet
import com.castdz.app.ui.components.MiniPlayerBar
import com.castdz.app.ui.components.PermissionRationaleDialog
import com.castdz.app.ui.screens.browser.WebBrowserScreen
import com.castdz.app.ui.screens.home.LocalMediaScreen
import com.castdz.app.ui.screens.library.LibraryScreen
import com.castdz.app.ui.screens.mirror.ScreenMirrorScreen
import com.castdz.app.ui.screens.onboarding.OnboardingScreen
import com.castdz.app.ui.screens.settings.SettingsScreen
import com.castdz.app.ui.theme.AccentCyan
import com.castdz.app.ui.theme.CosmicIndigo

private enum class CastDzTab(
    val route: String,
    val labelRes: Int,
    val icon: ImageVector
) {
    MEDIA("media", R.string.nav_media, Icons.Rounded.PermMedia),
    BROWSER("browser", R.string.nav_browser, Icons.Rounded.Language),
    MIRROR("mirror", R.string.nav_mirror, Icons.Rounded.ScreenShare),
    LIBRARY("library", R.string.nav_library, Icons.Rounded.CollectionsBookmark),
    SETTINGS("settings", R.string.nav_settings, Icons.Rounded.Settings)
}

@Composable
fun CastDzAppRoot(
    mainViewModel: MainViewModel
) {
    val context = LocalContext.current
    val settings by mainViewModel.settings.collectAsStateWithLifecycle()
    val devices by mainViewModel.devices.collectAsStateWithLifecycle()
    val isScanning by mainViewModel.isScanning.collectAsStateWithLifecycle()
    val diagnostics by mainViewModel.diagnostics.collectAsStateWithLifecycle()
    val playbackState by mainViewModel.playbackState.collectAsStateWithLifecycle()
    val webReceiverInfo by mainViewModel.webReceiverInfo.collectAsStateWithLifecycle()

    var showDeviceSheet by remember { mutableStateOf(false) }
    var showExpandedPlayer by remember { mutableStateOf(false) }
    var showPermissionRationale by remember { mutableStateOf(false) }
    var pendingBrowserUrl by remember { mutableStateOf<String?>(null) }

    val allPermissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        mainViewModel.refreshDiscovery()
    }

    fun launchPermissionRequest() {
        val perms = buildList {
            addAll(DiscoveryPermissionHelper.requiredDiscoveryPermissions())
            addAll(DiscoveryPermissionHelper.requiredMediaPermissions())
            addAll(DiscoveryPermissionHelper.optionalNotificationPermissions())
        }.distinct().toTypedArray()
        allPermissionsLauncher.launch(perms)
    }

    if (!settings.onboardingCompleted) {
        OnboardingScreen(
            onFinished = {
                mainViewModel.completeOnboarding()
                if (!DiscoveryPermissionHelper.hasDiscoveryPermissions(context)) {
                    showPermissionRationale = true
                }
            }
        )
        return
    }

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: CastDzTab.MEDIA.route

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 18.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(R.string.app_name),
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = stringResource(R.string.app_tagline),
                        style = MaterialTheme.typography.labelMedium,
                        color = AccentCyan
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                CastTopBarButton(
                    nearbyCount = devices.size,
                    isConnecting = playbackState.isConnecting,
                    connectedDeviceName = playbackState.connectedDevice?.name,
                    onClick = {
                        if (!DiscoveryPermissionHelper.hasDiscoveryPermissions(context)) {
                            showPermissionRationale = true
                        }
                        showDeviceSheet = true
                        mainViewModel.onDeviceSheetOpened()
                    }
                )
            }
        },
        bottomBar = {
            Column(modifier = Modifier.navigationBarsPadding()) {
                if (playbackState.connectedDevice != null) {
                    MiniPlayerBar(
                        playbackState = playbackState,
                        onExpand = { showExpandedPlayer = true },
                        onTogglePlayPause = mainViewModel::togglePlayPause,
                        onDisconnect = mainViewModel::disconnectDevice
                    )
                }
                NavigationBar(
                    containerColor = if (MaterialTheme.colorScheme.background == Color(0xFF0A0830)) {
                        CosmicIndigo.copy(alpha = 0.88f)
                    } else {
                        MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)
                    }
                ) {
                    CastDzTab.entries.forEach { tab ->
                        NavigationBarItem(
                            selected = currentRoute == tab.route,
                            onClick = {
                                navController.navigate(tab.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = stringResource(tab.labelRes)) },
                            label = { Text(stringResource(tab.labelRes)) }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            NavHost(
                navController = navController,
                startDestination = CastDzTab.MEDIA.route
            ) {
                composable(CastDzTab.MEDIA.route) {
                    LocalMediaScreen(
                        onOpenDevicePicker = {
                            showDeviceSheet = true
                            mainViewModel.onDeviceSheetOpened()
                        },
                        onRequestMediaPermission = { showPermissionRationale = true }
                    )
                }
                composable(CastDzTab.BROWSER.route) {
                    WebBrowserScreen(
                        initialUrl = pendingBrowserUrl,
                        onOpenDevicePicker = {
                            showDeviceSheet = true
                            mainViewModel.onDeviceSheetOpened()
                        }
                    )
                }
                composable(CastDzTab.MIRROR.route) {
                    ScreenMirrorScreen(
                        detectedDevices = devices,
                        isScanning = isScanning
                    )
                }
                composable(CastDzTab.LIBRARY.route) {
                    LibraryScreen(
                        onOpenDevicePicker = {
                            showDeviceSheet = true
                            mainViewModel.onDeviceSheetOpened()
                        },
                        onOpenBookmarkInBrowser = { url ->
                            pendingBrowserUrl = url
                            navController.navigate(CastDzTab.BROWSER.route) {
                                launchSingleTop = true
                            }
                        }
                    )
                }
                composable(CastDzTab.SETTINGS.route) {
                    SettingsScreen()
                }
            }
        }
    }

    if (showDeviceSheet) {
        DevicePickerSheet(
            devices = devices,
            isScanning = isScanning,
            diagnostics = diagnostics,
            webReceiverInfo = webReceiverInfo,
            onStartWebReceiver = mainViewModel::startWebReceiver,
            onDismiss = {
                showDeviceSheet = false
                mainViewModel.onDeviceSheetClosed()
            },
            onSelectDevice = { device ->
                mainViewModel.connectDevice(device)
                showDeviceSheet = false
                mainViewModel.onDeviceSheetClosed()
            },
            onDisconnect = mainViewModel::disconnectDevice,
            onRefresh = mainViewModel::refreshDiscovery,
            onAddManualDevice = mainViewModel::addManualDevice,
            onRequestDiscoveryPermission = { showPermissionRationale = true }
        )
    }

    if (showExpandedPlayer && playbackState.connectedDevice != null) {
        ExpandedPlayerSheet(
            playbackState = playbackState,
            onDismiss = { showExpandedPlayer = false },
            onTogglePlayPause = mainViewModel::togglePlayPause,
            onSeek = mainViewModel::seekTo,
            onVolumeChange = mainViewModel::setVolume,
            onToggleSubtitles = mainViewModel::toggleSubtitles,
            onNext = mainViewModel::playNext,
            onPrevious = mainViewModel::playPrevious,
            onPlayQueueItem = mainViewModel::playQueueItem,
            onRemoveQueueItem = mainViewModel::removeQueueItem,
            onDisconnect = {
                mainViewModel.disconnectDevice()
                showExpandedPlayer = false
            }
        )
    }

    if (showPermissionRationale) {
        PermissionRationaleDialog(
            onAllow = {
                showPermissionRationale = false
                launchPermissionRequest()
            },
            onDismiss = { showPermissionRationale = false }
        )
    }
}
