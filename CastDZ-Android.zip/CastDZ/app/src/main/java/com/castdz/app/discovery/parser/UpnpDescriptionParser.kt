package com.castdz.app.discovery.parser

import java.net.URI

data class UpnpDeviceDescription(
    val friendlyName: String,
    val manufacturer: String,
    val modelName: String,
    val udn: String?,
    val avTransportControlUrl: String?,
    val renderingControlUrl: String?,
    val deviceType: String?
)

/**
 * Pure Kotlin parser for UPnP / DLNA device description XML documents.
 * Uses resilient tag extraction (works identically in JVM unit tests and Android runtime
 * without depending on Android framework XmlPullParser stubs).
 */
object UpnpDescriptionParser {

    fun parse(xml: String, baseLocationUrl: String): UpnpDeviceDescription? {
        if (xml.isBlank() || !xml.contains("<device", ignoreCase = true)) return null

        val urlBase = extractTagValue(xml, "URLBase")?.takeIf { it.isNotBlank() } ?: baseLocationUrl
        val friendlyName = extractTagValue(xml, "friendlyName") ?: return null
        val manufacturer = extractTagValue(xml, "manufacturer") ?: "Unknown"
        val modelName = extractTagValue(xml, "modelName") ?: "Smart TV"
        val rawUdn = extractTagValue(xml, "UDN")
        val udn = rawUdn?.removePrefix("uuid:")?.removePrefix("UUID:")?.trim()?.lowercase()
        val deviceType = extractTagValue(xml, "deviceType")

        val services = extractServiceBlocks(xml)
        var avTransportUrl: String? = null
        var renderingUrl: String? = null

        for (block in services) {
            val serviceType = extractTagValue(block, "serviceType").orEmpty()
            val controlUrl = extractTagValue(block, "controlURL") ?: continue
            if (serviceType.contains("AVTransport", ignoreCase = true)) {
                avTransportUrl = resolveUrl(urlBase, controlUrl)
            } else if (serviceType.contains("RenderingControl", ignoreCase = true)) {
                renderingUrl = resolveUrl(urlBase, controlUrl)
            }
        }

        return UpnpDeviceDescription(
            friendlyName = decodeXmlEntities(friendlyName),
            manufacturer = decodeXmlEntities(manufacturer),
            modelName = decodeXmlEntities(modelName),
            udn = udn,
            avTransportControlUrl = avTransportUrl,
            renderingControlUrl = renderingUrl,
            deviceType = deviceType
        )
    }

    fun resolveUrl(baseUrl: String, relativeOrAbsolute: String): String {
        val trimmed = relativeOrAbsolute.trim()
        if (trimmed.startsWith("http://", ignoreCase = true) ||
            trimmed.startsWith("https://", ignoreCase = true)
        ) {
            return trimmed
        }
        return runCatching {
            val base = URI(baseUrl)
            base.resolve(trimmed).toString()
        }.getOrElse {
            val cleanBase = baseUrl.substringBeforeLast('/')
            if (trimmed.startsWith("/")) {
                val schemeAndHost = Regex("^(https?://[^/]+)").find(baseUrl)?.value ?: cleanBase
                "$schemeAndHost$trimmed"
            } else {
                "$cleanBase/$trimmed"
            }
        }
    }

    private fun extractTagValue(xml: String, tag: String): String? {
        val pattern = Regex(
            "<(?:[a-zA-Z0-9_\\-]+:)?$tag(?:\\s[^>]*)?>([\\s\\S]*?)</(?:[a-zA-Z0-9_\\-]+:)?$tag>",
            RegexOption.IGNORE_CASE
        )
        return pattern.find(xml)?.groupValues?.getOrNull(1)?.trim()
    }

    private fun extractServiceBlocks(xml: String): List<String> {
        val pattern = Regex(
            "<(?:[a-zA-Z0-9_\\-]+:)?service(?:\\s[^>]*)?>([\\s\\S]*?)</(?:[a-zA-Z0-9_\\-]+:)?service>",
            RegexOption.IGNORE_CASE
        )
        return pattern.findAll(xml).map { it.groupValues[1] }.toList()
    }

    private fun decodeXmlEntities(text: String): String {
        return text
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&apos;", "'")
    }
}
