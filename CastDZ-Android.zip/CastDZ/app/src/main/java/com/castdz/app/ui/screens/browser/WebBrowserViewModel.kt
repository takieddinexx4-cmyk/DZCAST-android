package com.castdz.app.ui.screens.browser

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.castdz.app.casting.CastSessionController
import com.castdz.app.casting.model.CastMediaItem
import com.castdz.app.casting.model.MediaSourceType
import com.castdz.app.data.local.entity.BookmarkEntity
import com.castdz.app.data.repository.UserDataRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

data class DetectedWebVideo(
    val url: String,
    val title: String,
    val mimeType: String
)

data class BrowserTab(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "CastDZ",
    val url: String = "https://www.google.com"
)

data class WebBrowserUiState(
    val tabs: List<BrowserTab> = listOf(BrowserTab()),
    val activeTabIndex: Int = 0,
    val urlInput: String = "https://www.google.com",
    val isLoading: Boolean = false,
    val detectedVideos: List<DetectedWebVideo> = emptyList()
) {
    val activeTab: BrowserTab get() = tabs.getOrElse(activeTabIndex) { tabs.first() }
}

@HiltViewModel
class WebBrowserViewModel @Inject constructor(
    private val userDataRepository: UserDataRepository,
    private val castSessionController: CastSessionController
) : ViewModel() {

    private val _uiState = MutableStateFlow(WebBrowserUiState())
    val uiState: StateFlow<WebBrowserUiState> = _uiState.asStateFlow()

    val bookmarks: StateFlow<List<BookmarkEntity>> = userDataRepository.bookmarks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun updateUrlInput(input: String) {
        _uiState.update { it.copy(urlInput = input) }
    }

    fun navigateTo(rawInput: String): String {
        val trimmed = rawInput.trim()
        val resolved = when {
            trimmed.startsWith("http://", ignoreCase = true) ||
                trimmed.startsWith("https://", ignoreCase = true) -> trimmed
            trimmed.contains(".") && !trimmed.contains(" ") -> "https://$trimmed"
            else -> "https://www.google.com/search?q=${android.net.Uri.encode(trimmed)}"
        }
        _uiState.update { state ->
            val updatedTabs = state.tabs.toMutableList()
            updatedTabs[state.activeTabIndex] = updatedTabs[state.activeTabIndex].copy(url = resolved)
            state.copy(
                tabs = updatedTabs,
                urlInput = resolved,
                detectedVideos = emptyList()
            )
        }
        return resolved
    }

    fun onPageStarted(url: String) {
        _uiState.update { state ->
            val updatedTabs = state.tabs.toMutableList()
            updatedTabs[state.activeTabIndex] = updatedTabs[state.activeTabIndex].copy(url = url)
            state.copy(tabs = updatedTabs, urlInput = url, isLoading = true)
        }
    }

    fun onPageFinished(url: String, title: String?) {
        _uiState.update { state ->
            val updatedTabs = state.tabs.toMutableList()
            updatedTabs[state.activeTabIndex] = updatedTabs[state.activeTabIndex].copy(
                url = url,
                title = title?.takeIf { it.isNotBlank() } ?: url
            )
            state.copy(tabs = updatedTabs, urlInput = url, isLoading = false)
        }
    }

    fun addTab() {
        _uiState.update { state ->
            val newTab = BrowserTab()
            val updated = state.tabs + newTab
            state.copy(
                tabs = updated,
                activeTabIndex = updated.lastIndex,
                urlInput = newTab.url,
                detectedVideos = emptyList()
            )
        }
    }

    fun selectTab(index: Int) {
        _uiState.update { state ->
            val safeIdx = index.coerceIn(0, state.tabs.lastIndex)
            state.copy(
                activeTabIndex = safeIdx,
                urlInput = state.tabs[safeIdx].url,
                detectedVideos = emptyList()
            )
        }
    }

    fun closeTab(index: Int) {
        _uiState.update { state ->
            if (state.tabs.size <= 1) return@update state
            val updated = state.tabs.toMutableList().apply { removeAt(index) }
            val nextIdx = index.coerceAtMost(updated.lastIndex)
            state.copy(
                tabs = updated,
                activeTabIndex = nextIdx,
                urlInput = updated[nextIdx].url,
                detectedVideos = emptyList()
            )
        }
    }

    fun onVideoDetected(url: String, pageTitle: String?) {
        val clean = url.trim()
        if (!clean.startsWith("http://", ignoreCase = true) &&
            !clean.startsWith("https://", ignoreCase = true)
        ) return

        val lower = clean.lowercase()
        // Never bypass DRM or capture license/key endpoints or analytics
        if (lower.contains("widevine") ||
            lower.contains("playready") ||
            lower.contains("fairplay") ||
            lower.contains("/drm/") ||
            lower.contains("license") ||
            lower.contains("doubleclick") ||
            lower.contains("googlesyndication")
        ) {
            return
        }

        val mime = inferMimeType(lower) ?: return
        _uiState.update { state ->
            if (state.detectedVideos.any { it.url == clean }) {
                state
            } else {
                val entry = DetectedWebVideo(
                    url = clean,
                    title = pageTitle?.takeIf { it.isNotBlank() }
                        ?: clean.substringAfterLast('/').substringBefore('?').ifBlank { "Web Video" },
                    mimeType = mime
                )
                // Put HLS/MP4 master playlists at the top
                val updated = (listOf(entry) + state.detectedVideos).take(25)
                state.copy(detectedVideos = updated)
            }
        }
    }

    fun toggleBookmark() {
        val tab = _uiState.value.activeTab
        viewModelScope.launch {
            val exists = bookmarks.value.any { it.url == tab.url }
            if (exists) {
                userDataRepository.removeBookmark(tab.url)
            } else {
                userDataRepository.addBookmark(title = tab.title, url = tab.url)
            }
        }
    }

    fun castDetectedVideo(video: DetectedWebVideo, onRequireDevicePicker: () -> Unit) {
        val item = CastMediaItem(
            id = "web-${video.url.hashCode()}",
            title = video.title,
            streamUrl = video.url,
            mimeType = video.mimeType,
            sourceType = MediaSourceType.WEB_VIDEO
        )
        castSessionController.castMedia(item)
        if (castSessionController.playbackState.value.connectedDevice == null) {
            onRequireDevicePicker()
        }
    }

    companion object {
        fun inferMimeType(lowerUrl: String): String? {
            val path = lowerUrl.substringBefore('?').substringBefore('#')
            return when {
                path.endsWith(".m3u8") || lowerUrl.contains(".m3u8") || lowerUrl.contains("format=m3u8") -> "application/x-mpegURL"
                path.endsWith(".mpd") || lowerUrl.contains(".mpd") -> "application/dash+xml"
                path.endsWith(".mp4") || lowerUrl.contains(".mp4?") || lowerUrl.contains("mime=video%2fmp4") || lowerUrl.contains("mime=video/mp4") -> "video/mp4"
                path.endsWith(".webm") || lowerUrl.contains(".webm?") || lowerUrl.contains("mime=video%2fwebm") -> "video/webm"
                path.endsWith(".m4v") || path.endsWith(".mov") -> "video/mp4"
                else -> null
            }
        }
    }
}
