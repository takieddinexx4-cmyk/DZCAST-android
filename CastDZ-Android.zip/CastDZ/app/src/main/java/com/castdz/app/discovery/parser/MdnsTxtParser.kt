package com.castdz.app.discovery.parser

import com.castdz.app.discovery.model.DeviceIconType

data class MdnsTxtMetadata(
    val friendlyName: String?,
    val model: String?,
    val uuid: String?,
    val capabilitiesMask: Int?
) {
    fun inferIconType(serviceType: String): DeviceIconType {
        val m = model.orEmpty().lowercase()
        return when {
            serviceType.contains("airplay", ignoreCase = true) -> DeviceIconType.APPLE_TV
            m.contains("chromecast") || m.contains("dongle") -> DeviceIconType.CHROMECAST
            m.contains("speaker") || m.contains("nest mini") || m.contains("home mini") || m.contains("audio") -> DeviceIconType.SPEAKER
            m.contains("tv") || m.contains("bravia") || m.contains("shield") || m.contains("mi box") || m.contains("android") -> DeviceIconType.TV
            else -> DeviceIconType.TV
        }
    }
}

/**
 * Pure Kotlin parser for mDNS / DNS-SD TXT records (NsdServiceInfo.attributes or raw key=value lines).
 * Extracts standard Google Cast / AirPlay / Android TV Remote TXT keys:
 * - fn: friendly name
 * - md / model: model name
 * - id / deviceid: device UUID
 * - ca: capability bitmask
 */
object MdnsTxtParser {

    fun parseAttributes(attributes: Map<String, ByteArray?>): MdnsTxtMetadata {
        val stringMap = attributes.entries.associate { (k, v) ->
            k.lowercase() to (v?.let { String(it, Charsets.UTF_8).trim() } ?: "")
        }
        return parseStringMap(stringMap)
    }

    fun parseRawLines(lines: List<String>): MdnsTxtMetadata {
        val map = mutableMapOf<String, String>()
        for (raw in lines) {
            val trimmed = raw.trim()
            if (trimmed.isEmpty()) continue
            val idx = trimmed.indexOf('=')
            if (idx > 0) {
                val key = trimmed.substring(0, idx).trim().lowercase()
                val value = trimmed.substring(idx + 1).trim()
                map[key] = value
            }
        }
        return parseStringMap(map)
    }

    fun parseStringMap(map: Map<String, String>): MdnsTxtMetadata {
        val lower = map.entries.associate { it.key.lowercase() to it.value.trim() }
        val fn = lower["fn"]?.takeIf { it.isNotEmpty() }
            ?: lower["n"]?.takeIf { it.isNotEmpty() }
        val md = lower["md"]?.takeIf { it.isNotEmpty() }
            ?: lower["model"]?.takeIf { it.isNotEmpty() }
        val id = lower["id"]?.takeIf { it.isNotEmpty() }
            ?: lower["deviceid"]?.takeIf { it.isNotEmpty() }
            ?: lower["bt"]?.takeIf { it.isNotEmpty() }
        val ca = lower["ca"]?.toIntOrNull()
        return MdnsTxtMetadata(
            friendlyName = fn,
            model = md,
            uuid = id?.lowercase(),
            capabilitiesMask = ca
        )
    }
}
