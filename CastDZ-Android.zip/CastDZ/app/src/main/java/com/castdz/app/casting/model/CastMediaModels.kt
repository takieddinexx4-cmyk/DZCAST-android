package com.castdz.app.casting.model

import android.net.Uri
import com.castdz.app.discovery.model.CastDevice

enum class MediaSourceType {
    LOCAL_FILE,
    WEB_VIDEO,
    DIRECT_URL
}

data class CastMediaItem(
    val id: String,
    val title: String,
    val subtitle: String? = null,
    val streamUrl: String,
    val localUri: Uri? = null,
    val mimeType: String = "video/mp4",
    val thumbnailUrl: String? = null,
    val subtitleUrl: String? = null,
    val durationMs: Long = 0L,
    val sourceType: MediaSourceType = MediaSourceType.WEB_VIDEO
)

data class CastPlaybackState(
    val connectedDevice: CastDevice? = null,
    val isConnecting: Boolean = false,
    val currentMedia: CastMediaItem? = null,
    val queue: List<CastMediaItem> = emptyList(),
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val volume: Float = 0.7f,
    val isMuted: Boolean = false,
    val subtitlesEnabled: Boolean = false,
    val activeSubtitleUrl: String? = null,
    val errorMessage: String? = null
)
