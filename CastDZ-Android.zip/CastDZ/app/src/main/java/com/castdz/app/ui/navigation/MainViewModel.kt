package com.castdz.app.ui.navigation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.castdz.app.casting.CastSessionController
import com.castdz.app.casting.model.CastMediaItem
import com.castdz.app.casting.model.CastPlaybackState
import com.castdz.app.casting.server.WebReceiverSessionInfo
import com.castdz.app.data.preferences.SettingsDataStore
import com.castdz.app.data.preferences.UserSettings
import com.castdz.app.discovery.DiscoveryEngine
import com.castdz.app.discovery.model.CastDevice
import com.castdz.app.discovery.model.CastProtocol
import com.castdz.app.discovery.model.DiscoveryDiagnostic
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    private val discoveryEngine: DiscoveryEngine,
    private val castSessionController: CastSessionController,
    private val settingsDataStore: SettingsDataStore
) : ViewModel() {

    val settings: StateFlow<UserSettings> = settingsDataStore.settings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), UserSettings())

    val devices: StateFlow<List<CastDevice>> = discoveryEngine.devices
    val isScanning: StateFlow<Boolean> = discoveryEngine.isScanning
    val diagnostics: StateFlow<List<DiscoveryDiagnostic>> = discoveryEngine.diagnostics
    val playbackState: StateFlow<CastPlaybackState> = castSessionController.playbackState
    val webReceiverInfo: StateFlow<WebReceiverSessionInfo> = castSessionController.webReceiverInfo

    fun completeOnboarding() {
        viewModelScope.launch {
            settingsDataStore.setOnboardingCompleted(true)
        }
    }

    fun onDeviceSheetOpened() = discoveryEngine.onDeviceSheetOpened()
    fun onDeviceSheetClosed() = discoveryEngine.onDeviceSheetClosed()
    fun refreshDiscovery() = discoveryEngine.refreshNow()

    fun startWebReceiver(regenerateCode: Boolean = false) {
        castSessionController.startWebReceiver(regenerateCode)
    }

    fun addManualDevice(ip: String, name: String?, protocol: CastProtocol) {
        discoveryEngine.addManualDevice(ip, name, protocol)
    }

    fun connectDevice(device: CastDevice) = castSessionController.connect(device)
    fun disconnectDevice() = castSessionController.disconnect()
    fun togglePlayPause() = castSessionController.togglePlayPause()
    fun seekTo(positionMs: Long) = castSessionController.seekTo(positionMs)
    fun setVolume(volume: Float) = castSessionController.setVolume(volume)
    fun toggleSubtitles(url: String?) = castSessionController.toggleSubtitles(url)
    fun playNext() = castSessionController.playNextInQueue()
    fun playPrevious() = castSessionController.playPreviousInQueue()
    fun playQueueItem(item: CastMediaItem) = castSessionController.castMedia(item)
    fun removeQueueItem(id: String) = castSessionController.removeFromQueue(id)
}
