package com.castdz.app.ui.screens.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.castdz.app.BuildConfig
import com.castdz.app.R
import com.castdz.app.data.preferences.AppLanguage
import com.castdz.app.data.preferences.AppThemeMode
import com.castdz.app.data.preferences.VideoQuality
import com.castdz.app.ui.components.GlassCard
import com.castdz.app.ui.theme.AccentCyan

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val devices by viewModel.nearbyDevices.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .padding(bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Language
        GlassCard(cornerRadius = 24.dp) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.settings_language),
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(10.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        AppLanguage.SYSTEM to R.string.settings_lang_system,
                        AppLanguage.ENGLISH to R.string.settings_lang_en,
                        AppLanguage.FRENCH to R.string.settings_lang_fr,
                        AppLanguage.ARABIC to R.string.settings_lang_ar
                    ).forEach { (lang, labelRes) ->
                        FilterChip(
                            selected = settings.language == lang,
                            onClick = { viewModel.setLanguage(lang) },
                            label = { Text(stringResource(labelRes)) }
                        )
                    }
                }
            }
        }

        // Theme
        GlassCard(cornerRadius = 24.dp) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.settings_theme),
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(10.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        AppThemeMode.SYSTEM to R.string.settings_theme_system,
                        AppThemeMode.DARK to R.string.settings_theme_dark,
                        AppThemeMode.LIGHT to R.string.settings_theme_light
                    ).forEach { (mode, labelRes) ->
                        FilterChip(
                            selected = settings.themeMode == mode,
                            onClick = { viewModel.setThemeMode(mode) },
                            label = { Text(stringResource(labelRes)) }
                        )
                    }
                }
            }
        }

        // Default device
        GlassCard(cornerRadius = 24.dp) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.settings_default_device),
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = settings.defaultDeviceName ?: stringResource(R.string.settings_default_device_none),
                    style = MaterialTheme.typography.bodyMedium,
                    color = AccentCyan
                )
                if (devices.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = settings.defaultDeviceId == null,
                            onClick = { viewModel.setDefaultDevice(null) },
                            label = { Text(stringResource(R.string.settings_default_device_none)) }
                        )
                        devices.forEach { dev ->
                            FilterChip(
                                selected = settings.defaultDeviceId == dev.id,
                                onClick = { viewModel.setDefaultDevice(dev) },
                                label = { Text(dev.name) }
                            )
                        }
                    }
                }
            }
        }

        // Video Quality
        GlassCard(cornerRadius = 24.dp) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.settings_video_quality),
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(10.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    VideoQuality.entries.forEach { quality ->
                        FilterChip(
                            selected = settings.videoQuality == quality,
                            onClick = { viewModel.setVideoQuality(quality) },
                            label = { Text(quality.label) }
                        )
                    }
                }
            }
        }

        // Debug "Fake Devices" mode
        GlassCard(cornerRadius = 24.dp) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.settings_debug_section),
                    style = MaterialTheme.typography.labelLarge,
                    color = AccentCyan
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.settings_fake_devices),
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = stringResource(R.string.settings_fake_devices_desc),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = settings.fakeDevicesEnabled,
                        onCheckedChange = viewModel::setFakeDevicesEnabled
                    )
                }
            }
        }

        // About
        GlassCard(cornerRadius = 24.dp) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = stringResource(R.string.settings_about),
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = stringResource(R.string.settings_version, BuildConfig.VERSION_NAME),
                    style = MaterialTheme.typography.labelLarge,
                    color = AccentCyan
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = stringResource(R.string.settings_about_desc),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
