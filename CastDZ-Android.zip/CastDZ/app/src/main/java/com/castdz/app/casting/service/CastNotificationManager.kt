package com.castdz.app.casting.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.castdz.app.MainActivity
import com.castdz.app.R
import com.castdz.app.casting.CastSessionController
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Crash-proof notification controller using NotificationManager + BroadcastReceiver
 * (avoids Android 14-16 ForegroundServiceStartNotAllowedException / RemoteServiceException).
 */
@Singleton
class CastNotificationManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val notificationManager: NotificationManager?
        get() = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager

    fun showOrUpdate(title: String, deviceName: String, isPlaying: Boolean) {
        runCatching {
            val nm = notificationManager ?: return
            ensureChannel(nm)

            val openAppIntent = PendingIntent.getActivity(
                context,
                0,
                Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                },
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

            val playPauseIntent = PendingIntent.getBroadcast(
                context,
                1,
                Intent(context, CastNotificationActionReceiver::class.java).apply {
                    action = ACTION_TOGGLE_PLAY
                },
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

            val nextIntent = PendingIntent.getBroadcast(
                context,
                2,
                Intent(context, CastNotificationActionReceiver::class.java).apply {
                    action = ACTION_NEXT
                },
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

            val disconnectIntent = PendingIntent.getBroadcast(
                context,
                3,
                Intent(context, CastNotificationActionReceiver::class.java).apply {
                    action = ACTION_DISCONNECT
                },
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

            val playPauseIcon = if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
            val playPauseLabel = context.getString(if (isPlaying) R.string.action_pause else R.string.action_play)

            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_cast_notification)
                .setContentTitle(title)
                .setContentText(context.getString(R.string.casting_to_device, deviceName))
                .setContentIntent(openAppIntent)
                .setOngoing(true)
                .setSilent(true)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .addAction(playPauseIcon, playPauseLabel, playPauseIntent)
                .addAction(android.R.drawable.ic_media_next, context.getString(R.string.action_next), nextIntent)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, context.getString(R.string.action_disconnect), disconnectIntent)
                .build()

            nm.notify(NOTIFICATION_ID, notification)
        }
    }

    fun cancel() {
        runCatching {
            notificationManager?.cancel(NOTIFICATION_ID)
        }
    }

    private fun ensureChannel(nm: NotificationManager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                context.getString(R.string.notification_channel_cast),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                setShowBadge(false)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
            }
            nm.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "castdz_playback_channel"
        const val NOTIFICATION_ID = 2048
        const val ACTION_TOGGLE_PLAY = "com.castdz.app.ACTION_TOGGLE_PLAY"
        const val ACTION_NEXT = "com.castdz.app.ACTION_NEXT"
        const val ACTION_DISCONNECT = "com.castdz.app.ACTION_DISCONNECT"
    }
}

@AndroidEntryPoint
class CastNotificationActionReceiver : BroadcastReceiver() {

    @Inject
    lateinit var castSessionController: CastSessionController

    override fun onReceive(context: Context, intent: Intent?) {
        runCatching {
            when (intent?.action) {
                CastNotificationManager.ACTION_TOGGLE_PLAY -> castSessionController.togglePlayPause()
                CastNotificationManager.ACTION_NEXT -> castSessionController.playNextInQueue()
                CastNotificationManager.ACTION_DISCONNECT -> castSessionController.disconnect()
            }
        }
    }
}
