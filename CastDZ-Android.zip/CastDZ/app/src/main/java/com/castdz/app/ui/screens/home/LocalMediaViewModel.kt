package com.castdz.app.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.castdz.app.casting.CastSessionController
import com.castdz.app.casting.model.CastMediaItem
import com.castdz.app.casting.model.MediaSourceType
import com.castdz.app.data.repository.LocalMediaItem
import com.castdz.app.data.repository.LocalMediaType
import com.castdz.app.data.repository.MediaLibraryRepository
import com.castdz.app.data.repository.UserDataRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class LocalMediaUiState(
    val selectedType: LocalMediaType = LocalMediaType.VIDEO,
    val searchQuery: String = "",
    val items: List<LocalMediaItem> = emptyList(),
    val favoriteUrls: Set<String> = emptySet(),
    val isLoading: Boolean = false
)

@HiltViewModel
class LocalMediaViewModel @Inject constructor(
    private val mediaRepository: MediaLibraryRepository,
    private val userDataRepository: UserDataRepository,
    private val castSessionController: CastSessionController
) : ViewModel() {

    private val selectedType = MutableStateFlow(LocalMediaType.VIDEO)
    private val searchQuery = MutableStateFlow("")
    private val rawItems = MutableStateFlow<List<LocalMediaItem>>(emptyList())
    private val isLoading = MutableStateFlow(false)

    val uiState: StateFlow<LocalMediaUiState> = combine(
        selectedType,
        searchQuery,
        rawItems,
        userDataRepository.favorites,
        isLoading
    ) { type, query, list, favs, loading ->
        val filtered = if (query.isBlank()) {
            list
        } else {
            list.filter { it.title.contains(query, ignoreCase = true) }
        }
        LocalMediaUiState(
            selectedType = type,
            searchQuery = query,
            items = filtered,
            favoriteUrls = favs.map { it.url }.toSet(),
            isLoading = loading
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), LocalMediaUiState())

    fun selectType(type: LocalMediaType) {
        selectedType.value = type
        refresh()
    }

    fun updateSearch(query: String) {
        searchQuery.value = query
    }

    fun refresh() {
        viewModelScope.launch {
            isLoading.value = true
            rawItems.value = mediaRepository.loadMedia(selectedType.value)
            isLoading.value = false
        }
    }

    fun castLocalItem(item: LocalMediaItem, onRequireDevicePicker: () -> Unit) {
        val castItem = CastMediaItem(
            id = "local-${item.id}",
            title = item.title,
            streamUrl = item.uri.toString(),
            localUri = item.uri,
            mimeType = item.mimeType,
            durationMs = item.durationMs,
            sourceType = MediaSourceType.LOCAL_FILE
        )
        castSessionController.castMedia(castItem)
        if (castSessionController.playbackState.value.connectedDevice == null) {
            onRequireDevicePicker()
        }
    }

    fun toggleFavorite(item: LocalMediaItem) {
        val url = item.uri.toString()
        viewModelScope.launch {
            if (uiState.value.favoriteUrls.contains(url)) {
                userDataRepository.removeFavorite(url)
            } else {
                userDataRepository.addFavorite(
                    title = item.title,
                    url = url,
                    mimeType = item.mimeType
                )
            }
        }
    }
}
