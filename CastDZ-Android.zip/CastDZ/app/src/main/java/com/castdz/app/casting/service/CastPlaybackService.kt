package com.castdz.app.casting.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.castdz.app.MainActivity
import com.castdz.app.R
import com.castdz.app.casting.CastSessionController
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

/**
 * Foreground service displaying a persistent media notification and lock-screen
 * controller while casting to a screen. Uses ServiceCompat.startForeground with
 * explicit FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK for Android 14–16 safety.
 */
@AndroidEntryPoint
class CastPlaybackService : Service() {

    @Inject
    lateinit var castSessionController: CastSessionController

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureNotificationChannel()

        when (intent?.action) {
            ACTION_TOGGLE_PLAY -> castSessionController.togglePlayPause()
            ACTION_NEXT -> castSessionController.playNextInQueue()
            ACTION_DISCONNECT -> {
                castSessionController.disconnect()
                runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
                stopSelf()
                return START_NOT_STICKY
            }
        }

        val state = castSessionController.playbackState.value
        val title = intent?.getStringExtra(EXTRA_TITLE)
            ?: state.currentMedia?.title
            ?: getString(R.string.app_name)
        val device = intent?.getStringExtra(EXTRA_DEVICE)
            ?: state.connectedDevice?.name
            ?: ""
        val isPlaying = intent?.getBooleanExtra(EXTRA_IS_PLAYING, state.isPlaying)
            ?: state.isPlaying

        val notification = buildNotification(title, device, isPlaying)
        val started = runCatching {
            val fgsType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            } else {
                0
            }
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, fgsType)
            true
        }.getOrDefault(false)

        if (!started) {
            // Fallback: post as a regular notification without crashing the app
            runCatching {
                val nm = getSystemService(NotificationManager::class.java)
                nm.notify(NOTIFICATION_ID, notification)
            }
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(title: String, deviceName: String, isPlaying: Boolean): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val playPauseIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, CastPlaybackService::class.java).apply { action = ACTION_TOGGLE_PLAY },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val nextIntent = PendingIntent.getService(
            this,
            2,
            Intent(this, CastPlaybackService::class.java).apply { action = ACTION_NEXT },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val disconnectIntent = PendingIntent.getService(
            this,
            3,
            Intent(this, CastPlaybackService::class.java).apply { action = ACTION_DISCONNECT },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val playPauseIcon = if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val playPauseLabel = if (isPlaying) getString(R.string.action_pause) else getString(R.string.action_play)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_cast_notification)
            .setContentTitle(title)
            .setContentText(getString(R.string.casting_to_device, deviceName))
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .setSilent(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(playPauseIcon, playPauseLabel, playPauseIntent)
            .addAction(android.R.drawable.ic_media_next, getString(R.string.action_next), nextIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, getString(R.string.action_disconnect), disconnectIntent)
            .build()
    }

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_cast),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            nm.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "castdz_playback_channel"
        const val NOTIFICATION_ID = 2048
        const val ACTION_UPDATE = "com.castdz.app.ACTION_UPDATE"
        const val ACTION_TOGGLE_PLAY = "com.castdz.app.ACTION_TOGGLE_PLAY"
        const val ACTION_NEXT = "com.castdz.app.ACTION_NEXT"
        const val ACTION_DISCONNECT = "com.castdz.app.ACTION_DISCONNECT"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_DEVICE = "extra_device"
        const val EXTRA_IS_PLAYING = "extra_is_playing"
    }
}
