package com.castdz.app.ui.screens.library

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.castdz.app.casting.CastSessionController
import com.castdz.app.casting.model.CastMediaItem
import com.castdz.app.casting.model.MediaSourceType
import com.castdz.app.data.local.entity.BookmarkEntity
import com.castdz.app.data.local.entity.FavoriteEntity
import com.castdz.app.data.local.entity.HistoryEntity
import com.castdz.app.data.repository.UserDataRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val userDataRepository: UserDataRepository,
    private val castSessionController: CastSessionController
) : ViewModel() {

    val history: StateFlow<List<HistoryEntity>> = userDataRepository.history
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val favorites: StateFlow<List<FavoriteEntity>> = userDataRepository.favorites
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val bookmarks: StateFlow<List<BookmarkEntity>> = userDataRepository.bookmarks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun deleteHistory(item: HistoryEntity) {
        viewModelScope.launch { userDataRepository.deleteHistory(item) }
    }

    fun clearHistory() {
        viewModelScope.launch { userDataRepository.clearHistory() }
    }

    fun deleteFavorite(url: String) {
        viewModelScope.launch { userDataRepository.removeFavorite(url) }
    }

    fun deleteBookmark(url: String) {
        viewModelScope.launch { userDataRepository.removeBookmark(url) }
    }

    fun replayMedia(title: String, url: String, mimeType: String, onRequireDevicePicker: () -> Unit) {
        val isLocal = url.startsWith("content://")
        val item = CastMediaItem(
            id = "lib-${url.hashCode()}",
            title = title,
            streamUrl = url,
            localUri = if (isLocal) Uri.parse(url) else null,
            mimeType = mimeType,
            sourceType = if (isLocal) MediaSourceType.LOCAL_FILE else MediaSourceType.WEB_VIDEO
        )
        castSessionController.castMedia(item)
        if (castSessionController.playbackState.value.connectedDevice == null) {
            onRequireDevicePicker()
        }
    }
}
