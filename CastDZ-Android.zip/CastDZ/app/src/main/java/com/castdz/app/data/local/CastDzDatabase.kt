package com.castdz.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.castdz.app.data.local.dao.BookmarkDao
import com.castdz.app.data.local.dao.FavoriteDao
import com.castdz.app.data.local.dao.HistoryDao
import com.castdz.app.data.local.entity.BookmarkEntity
import com.castdz.app.data.local.entity.FavoriteEntity
import com.castdz.app.data.local.entity.HistoryEntity

@Database(
    entities = [HistoryEntity::class, FavoriteEntity::class, BookmarkEntity::class],
    version = 1,
    exportSchema = false
)
abstract class CastDzDatabase : RoomDatabase() {
    abstract fun historyDao(): HistoryDao
    abstract fun favoriteDao(): FavoriteDao
    abstract fun bookmarkDao(): BookmarkDao
}
