package com.castdz.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import com.castdz.app.data.preferences.AppThemeMode

data class CastDzExtendedColors(
    val isDark: Boolean,
    val bgGradient: List<Color>,
    val glassSurface: Color,
    val glassBorder: Color,
    val cyan: Color = AccentCyan,
    val violet: Color = AccentViolet,
    val pink: Color = AccentPink,
    val amber: Color = AccentAmber,
    val green: Color = AccentGreen
)

val LocalCastDzColors = staticCompositionLocalOf {
    CastDzExtendedColors(
        isDark = true,
        bgGradient = listOf(DeepNavy, CosmicIndigo, AbyssalTeal),
        glassSurface = GlassDarkSurface,
        glassBorder = GlassDarkBorder
    )
}

private val CastDzDarkColorScheme = darkColorScheme(
    primary = AccentCyan,
    onPrimary = DeepNavy,
    secondary = AccentViolet,
    onSecondary = Color.White,
    tertiary = AccentPink,
    onTertiary = Color.White,
    background = DeepNavy,
    onBackground = OnDarkPrimary,
    surface = CosmicIndigo,
    onSurface = OnDarkPrimary,
    surfaceVariant = Color(0xFF1F1954),
    onSurfaceVariant = OnDarkSecondary,
    error = Color(0xFFFF5A79),
    onError = Color.White
)

private val CastDzLightColorScheme = lightColorScheme(
    primary = Color(0xFF007EA7),
    onPrimary = Color.White,
    secondary = AccentViolet,
    onSecondary = Color.White,
    tertiary = AccentPink,
    onTertiary = Color.White,
    background = LightBgStart,
    onBackground = OnLightPrimary,
    surface = Color.White,
    onSurface = OnLightPrimary,
    surfaceVariant = Color(0xFFE7ECFF),
    onSurfaceVariant = OnLightSecondary,
    error = Color(0xFFD32F4F),
    onError = Color.White
)

@Composable
fun CastDzTheme(
    themeMode: AppThemeMode = AppThemeMode.DARK,
    content: @Composable () -> Unit
) {
    val isDark = when (themeMode) {
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val configuration = LocalConfiguration.current
    val locale = configuration.locales[0]
    val isArabic = locale?.language?.equals("ar", ignoreCase = true) == true

    val extended = if (isDark) {
        CastDzExtendedColors(
            isDark = true,
            bgGradient = listOf(DeepNavy, CosmicIndigo, AbyssalTeal),
            glassSurface = GlassDarkSurface,
            glassBorder = GlassDarkBorder
        )
    } else {
        CastDzExtendedColors(
            isDark = false,
            bgGradient = listOf(LightBgStart, LightBgMid, LightBgEnd),
            glassSurface = GlassLightSurface,
            glassBorder = GlassLightBorder
        )
    }

    CompositionLocalProvider(LocalCastDzColors provides extended) {
        MaterialTheme(
            colorScheme = if (isDark) CastDzDarkColorScheme else CastDzLightColorScheme,
            typography = castDzTypography(isArabic),
            content = content
        )
    }
}
