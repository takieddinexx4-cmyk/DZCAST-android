package com.castdz.app.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.PermMedia
import androidx.compose.material.icons.rounded.WifiFind
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.castdz.app.R
import com.castdz.app.ui.theme.AccentCyan
import com.castdz.app.ui.theme.AccentGreen
import com.castdz.app.ui.theme.AccentPink
import com.castdz.app.ui.theme.AccentViolet

@Composable
fun PermissionRationaleDialog(
    onAllow: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = stringResource(R.string.perm_rationale_title),
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(
                    text = stringResource(R.string.perm_rationale_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                PermissionItemRow(
                    icon = Icons.Rounded.WifiFind,
                    title = stringResource(R.string.perm_nearby_title),
                    description = stringResource(R.string.perm_nearby_desc),
                    colors = listOf(AccentCyan, AccentViolet)
                )
                PermissionItemRow(
                    icon = Icons.Rounded.PermMedia,
                    title = stringResource(R.string.perm_media_title),
                    description = stringResource(R.string.perm_media_desc),
                    colors = listOf(AccentViolet, AccentPink)
                )
                PermissionItemRow(
                    icon = Icons.Rounded.Notifications,
                    title = stringResource(R.string.perm_notif_title),
                    description = stringResource(R.string.perm_notif_desc),
                    colors = listOf(AccentGreen, AccentCyan)
                )
            }
        },
        confirmButton = {
            Button(onClick = onAllow) {
                Text(stringResource(R.string.perm_allow_continue))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.perm_not_now))
            }
        }
    )
}

@Composable
private fun PermissionItemRow(
    icon: ImageVector,
    title: String,
    description: String,
    colors: List<Color>
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Icon3D(
            imageVector = icon,
            contentDescription = null,
            gradientColors = colors,
            size = 38.dp,
            iconSize = 20.dp,
            enableParallax = false
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
