package com.castdz.app.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Cast
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PermMedia
import androidx.compose.material.icons.rounded.PlayCircleOutline
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.castdz.app.R
import com.castdz.app.core.permissions.DiscoveryPermissionHelper
import com.castdz.app.data.repository.LocalMediaItem
import com.castdz.app.data.repository.LocalMediaType
import com.castdz.app.ui.components.ExoPreviewDialog
import com.castdz.app.ui.components.GlassCard
import com.castdz.app.ui.components.Icon3D
import com.castdz.app.ui.components.StateFeedbackCard
import com.castdz.app.ui.components.formatDuration
import com.castdz.app.ui.theme.AccentCyan
import com.castdz.app.ui.theme.AccentGreen
import com.castdz.app.ui.theme.AccentPink
import com.castdz.app.ui.theme.AccentViolet

@Composable
fun LocalMediaScreen(
    onOpenDevicePicker: () -> Unit,
    onRequestMediaPermission: () -> Unit,
    viewModel: LocalMediaViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val hasPermission = DiscoveryPermissionHelper.hasMediaPermissions(context)
    var previewItem by remember { mutableStateOf<LocalMediaItem?>(null) }

    LaunchedEffect(hasPermission, state.selectedType) {
        if (hasPermission) {
            viewModel.refresh()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Category chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = state.selectedType == LocalMediaType.VIDEO,
                onClick = { viewModel.selectType(LocalMediaType.VIDEO) },
                label = { Text(stringResource(R.string.media_tab_videos)) },
                leadingIcon = { Icon(Icons.Rounded.VideoLibrary, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
            FilterChip(
                selected = state.selectedType == LocalMediaType.PHOTO,
                onClick = { viewModel.selectType(LocalMediaType.PHOTO) },
                label = { Text(stringResource(R.string.media_tab_photos)) },
                leadingIcon = { Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
            FilterChip(
                selected = state.selectedType == LocalMediaType.AUDIO,
                onClick = { viewModel.selectType(LocalMediaType.AUDIO) },
                label = { Text(stringResource(R.string.media_tab_audio)) },
                leadingIcon = { Icon(Icons.Rounded.MusicNote, contentDescription = null, modifier = Modifier.size(18.dp)) }
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = state.searchQuery,
            onValueChange = viewModel::updateSearch,
            placeholder = { Text(stringResource(R.string.media_search_hint)) },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
            singleLine = true,
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        if (!hasPermission) {
            StateFeedbackCard(
                icon = Icons.Rounded.PermMedia,
                title = stringResource(R.string.perm_media_title),
                description = stringResource(R.string.media_permission_needed),
                gradientColors = listOf(AccentViolet, AccentPink),
                actionLabel = stringResource(R.string.action_grant_permission),
                onAction = onRequestMediaPermission
            )
        } else if (state.isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AccentCyan)
            }
        } else if (state.items.isEmpty()) {
            StateFeedbackCard(
                icon = Icons.Rounded.VideoLibrary,
                title = stringResource(R.string.media_empty_title),
                description = stringResource(R.string.media_empty_desc),
                actionLabel = stringResource(R.string.action_refresh),
                onAction = viewModel::refresh
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(bottom = 120.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(state.items, key = { "${it.type.name}-${it.id}" }) { item ->
                    val isFav = state.favoriteUrls.contains(item.uri.toString())
                    GlassCard(
                        cornerRadius = 22.dp,
                        onClick = { viewModel.castLocalItem(item, onOpenDevicePicker) }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (item.type == LocalMediaType.AUDIO) {
                                Icon3D(
                                    imageVector = Icons.Rounded.MusicNote,
                                    contentDescription = null,
                                    gradientColors = listOf(AccentPink, AccentViolet),
                                    size = 54.dp,
                                    iconSize = 26.dp,
                                    enableParallax = false
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(54.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(AccentViolet.copy(alpha = 0.25f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    AsyncImage(
                                        model = item.uri,
                                        contentDescription = item.title,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                val subtitle = buildString {
                                    if (item.durationMs > 0L) {
                                        append(formatDuration(item.durationMs))
                                        append(" • ")
                                    }
                                    append(formatSizeMb(item.sizeBytes))
                                }
                                Text(
                                    text = subtitle,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            if (item.type != LocalMediaType.PHOTO) {
                                IconButton(onClick = { previewItem = item }) {
                                    Icon(
                                        imageVector = Icons.Rounded.PlayCircleOutline,
                                        contentDescription = stringResource(R.string.action_preview),
                                        tint = AccentGreen
                                    )
                                }
                            }
                            IconButton(onClick = { viewModel.toggleFavorite(item) }) {
                                Icon(
                                    imageVector = if (isFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                                    contentDescription = stringResource(R.string.library_tab_favorites),
                                    tint = if (isFav) AccentPink else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { viewModel.castLocalItem(item, onOpenDevicePicker) }) {
                                Icon(
                                    imageVector = Icons.Rounded.Cast,
                                    contentDescription = stringResource(R.string.action_cast),
                                    tint = AccentCyan
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    previewItem?.let { item ->
        ExoPreviewDialog(
            title = item.title,
            uri = item.uri,
            onCastClick = { viewModel.castLocalItem(item, onOpenDevicePicker) },
            onDismiss = { previewItem = null }
        )
    }
}

private fun formatSizeMb(bytes: Long): String {
    val mb = bytes / (1024.0 * 1024.0)
    return if (mb >= 1.0) "%.1f MB".format(mb) else "${(bytes / 1024L).coerceAtLeast(1L)} KB"
}
