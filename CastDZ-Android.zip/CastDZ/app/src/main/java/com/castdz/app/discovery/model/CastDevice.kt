package com.castdz.app.discovery.model

enum class CastProtocol {
    CAST,
    DLNA,
    AIRPLAY,
    ROKU
}

enum class DeviceIconType {
    TV,
    CHROMECAST,
    SPEAKER,
    APPLE_TV,
    ROKU,
    GENERIC
}

enum class DeviceConnectionState {
    AVAILABLE,
    CONNECTING,
    CONNECTED
}

data class CastDevice(
    val id: String,
    val name: String,
    val model: String,
    val manufacturer: String,
    val protocol: CastProtocol,
    val ip: String,
    val port: Int = 8009,
    val controlUrl: String? = null,
    val renderingControlUrl: String? = null,
    val mediaRouteId: String? = null,
    val iconType: DeviceIconType = DeviceIconType.TV,
    val state: DeviceConnectionState = DeviceConnectionState.AVAILABLE,
    val lastSeen: Long = System.currentTimeMillis(),
    val isManual: Boolean = false
)

enum class DiagnosticCause {
    WIFI_OFF,
    MOBILE_DATA_ONLY,
    PERMISSION_DENIED,
    VPN_ACTIVE,
    AP_ISOLATION
}

data class DiscoveryDiagnostic(
    val cause: DiagnosticCause,
    val canOneTapFix: Boolean = true
)
