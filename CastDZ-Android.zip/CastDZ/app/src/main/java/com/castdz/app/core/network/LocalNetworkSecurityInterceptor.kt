package com.castdz.app.core.network

import okhttp3.Interceptor
import okhttp3.Response
import java.io.IOException
import java.net.InetAddress

/**
 * Enforces that cleartext HTTP requests initiated by CastDZ's HTTP client
 * (SSDP location XML fetches, DLNA SOAP calls) are strictly limited to
 * private local-network addresses (RFC 1918 / link-local / loopback).
 */
class LocalNetworkSecurityInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        if (!request.isHttps) {
            val host = request.url.host
            if (!isLocalNetworkHost(host)) {
                throw IOException("Cleartext HTTP blocked for non-local host: $host")
            }
        }
        return chain.proceed(request)
    }

    companion object {
        fun isLocalNetworkHost(host: String): Boolean {
            if (host.equals("localhost", ignoreCase = true) || host == "127.0.0.1" || host == "::1") {
                return true
            }
            if (host.endsWith(".local", ignoreCase = true)) {
                return true
            }
            return runCatching {
                val address = InetAddress.getByName(host)
                address.isSiteLocalAddress || address.isLoopbackAddress || address.isLinkLocalAddress
            }.getOrDefault(false)
        }
    }
}
