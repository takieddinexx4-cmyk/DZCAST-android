package com.castdz.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cast_history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val url: String,
    val mimeType: String,
    val thumbnailUrl: String? = null,
    val deviceName: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val url: String,
    val title: String,
    val mimeType: String,
    val thumbnailUrl: String? = null,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey val url: String,
    val title: String,
    val faviconUrl: String? = null,
    val addedAt: Long = System.currentTimeMillis()
)
