package com.castdz.app.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CastConnected
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.castdz.app.R
import com.castdz.app.casting.model.CastPlaybackState
import com.castdz.app.ui.theme.AccentCyan
import com.castdz.app.ui.theme.AccentPink
import com.castdz.app.ui.theme.AccentViolet

@Composable
fun MiniPlayerBar(
    playbackState: CastPlaybackState,
    onExpand: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onDisconnect: () -> Unit,
    modifier: Modifier = Modifier
) {
    val device = playbackState.connectedDevice ?: return
    val progress = if (playbackState.durationMs > 0L) {
        (playbackState.positionMs.toFloat() / playbackState.durationMs.toFloat()).coerceIn(0f, 1f)
    } else 0f

    GlassCard(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        cornerRadius = 22.dp,
        borderColor = AccentCyan.copy(alpha = 0.5f),
        onClick = onExpand
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon3D(
                    imageVector = Icons.Rounded.CastConnected,
                    contentDescription = null,
                    gradientColors = listOf(AccentCyan, AccentViolet),
                    size = 40.dp,
                    iconSize = 20.dp,
                    enableParallax = false
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = playbackState.currentMedia?.title ?: stringResource(R.string.player_connected_ready),
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = stringResource(R.string.casting_to_device, device.name),
                        style = MaterialTheme.typography.bodyMedium,
                        color = AccentCyan,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (playbackState.currentMedia != null) {
                    IconButton(onClick = onTogglePlayPause) {
                        Icon(
                            imageVector = if (playbackState.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = stringResource(
                                if (playbackState.isPlaying) R.string.action_pause else R.string.action_play
                            ),
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
                IconButton(onClick = onDisconnect) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = stringResource(R.string.action_disconnect),
                        tint = AccentPink
                    )
                }
            }
            if (playbackState.currentMedia != null) {
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxWidth(),
                    color = AccentCyan,
                    trackColor = AccentViolet.copy(alpha = 0.25f)
                )
            }
        }
    }
}
