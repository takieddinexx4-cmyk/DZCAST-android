package com.castdz.app.data.repository

import com.castdz.app.data.local.dao.BookmarkDao
import com.castdz.app.data.local.dao.FavoriteDao
import com.castdz.app.data.local.dao.HistoryDao
import com.castdz.app.data.local.entity.BookmarkEntity
import com.castdz.app.data.local.entity.FavoriteEntity
import com.castdz.app.data.local.entity.HistoryEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UserDataRepository @Inject constructor(
    private val historyDao: HistoryDao,
    private val favoriteDao: FavoriteDao,
    private val bookmarkDao: BookmarkDao
) {
    val history: Flow<List<HistoryEntity>> = historyDao.observeAll()
    val favorites: Flow<List<FavoriteEntity>> = favoriteDao.observeAll()
    val bookmarks: Flow<List<BookmarkEntity>> = bookmarkDao.observeAll()

    suspend fun recordHistory(
        title: String,
        url: String,
        mimeType: String,
        thumbnailUrl: String? = null,
        deviceName: String? = null
    ) {
        historyDao.insert(
            HistoryEntity(
                title = title,
                url = url,
                mimeType = mimeType,
                thumbnailUrl = thumbnailUrl,
                deviceName = deviceName
            )
        )
    }

    suspend fun deleteHistory(item: HistoryEntity) = historyDao.delete(item)
    suspend fun clearHistory() = historyDao.clearAll()

    fun isFavorite(url: String): Flow<Boolean> = favoriteDao.isFavorite(url)

    suspend fun addFavorite(title: String, url: String, mimeType: String, thumbnailUrl: String? = null) {
        favoriteDao.upsert(
            FavoriteEntity(
                url = url,
                title = title,
                mimeType = mimeType,
                thumbnailUrl = thumbnailUrl
            )
        )
    }

    suspend fun removeFavorite(url: String) = favoriteDao.deleteByUrl(url)

    fun isBookmarked(url: String): Flow<Boolean> = bookmarkDao.isBookmarked(url)

    suspend fun addBookmark(title: String, url: String, faviconUrl: String? = null) {
        bookmarkDao.upsert(BookmarkEntity(url = url, title = title, faviconUrl = faviconUrl))
    }

    suspend fun removeBookmark(url: String) = bookmarkDao.deleteByUrl(url)
}
