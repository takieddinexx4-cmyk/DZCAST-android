package com.castdz.app.ui.components

import android.os.Build
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.castdz.app.core.motion.rememberReduceMotionEnabled
import com.castdz.app.ui.theme.AccentCyan
import com.castdz.app.ui.theme.AccentPink
import com.castdz.app.ui.theme.AccentViolet
import com.castdz.app.ui.theme.LocalCastDzColors

/**
 * Full-screen gradient canvas with soft glowing ambient color blobs behind glassmorphic cards.
 */
@Composable
fun CastDzBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val colors = LocalCastDzColors.current
    val reduceMotion = rememberReduceMotionEnabled()

    val drift = if (!reduceMotion) {
        val transition = rememberInfiniteTransition(label = "bgBlobs")
        val anim by transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(14000, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "blobDrift"
        )
        anim
    } else {
        0.5f
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.linearGradient(colors.bgGradient))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val alphaScale = if (colors.isDark) 0.24f else 0.16f

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(AccentCyan.copy(alpha = alphaScale), Color.Transparent),
                    center = Offset(w * (0.15f + 0.12f * drift), h * 0.14f),
                    radius = w * 0.65f
                ),
                radius = w * 0.65f,
                center = Offset(w * (0.15f + 0.12f * drift), h * 0.14f)
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(AccentViolet.copy(alpha = alphaScale * 1.1f), Color.Transparent),
                    center = Offset(w * (0.85f - 0.1f * drift), h * 0.48f),
                    radius = w * 0.72f
                ),
                radius = w * 0.72f,
                center = Offset(w * (0.85f - 0.1f * drift), h * 0.48f)
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(AccentPink.copy(alpha = alphaScale * 0.85f), Color.Transparent),
                    center = Offset(w * (0.3f + 0.15f * drift), h * 0.88f),
                    radius = w * 0.6f
                ),
                radius = w * 0.6f,
                center = Offset(w * (0.3f + 0.15f * drift), h * 0.88f)
            )
        }
        content()
    }
}

/**
 * Translucent glassmorphic card with 24–32dp rounded corners, 1dp luminous border,
 * soft shadow, and Android 12+ RenderEffect blur backdrop layer with clean translucent fallback below.
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 26.dp,
    borderColor: Color? = null,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val colors = LocalCastDzColors.current
    val shape: Shape = RoundedCornerShape(cornerRadius)
    val resolvedBorder = borderColor ?: colors.glassBorder
    val baseFill = if (colors.isDark) Color(0x301B1648) else Color(0xCCFFFFFF)
    val highlightGradient = Brush.linearGradient(
        colors = if (colors.isDark) {
            listOf(Color(0x28FFFFFF), Color(0x0DFFFFFF), Color(0x1600E5FF))
        } else {
            listOf(Color(0xE6FFFFFF), Color(0xB3FFFFFF))
        }
    )

    Box(
        modifier = modifier
            .shadow(
                elevation = if (colors.isDark) 12.dp else 6.dp,
                shape = shape,
                ambientColor = AccentViolet.copy(alpha = 0.25f),
                spotColor = AccentCyan.copy(alpha = 0.2f)
            )
            .clip(shape)
            .background(baseFill)
            .then(
                if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
            )
            .border(width = 1.dp, color = resolvedBorder, shape = shape)
    ) {
        // Blurred translucent backdrop glaze on Android 12+ (API 31+), clean translucent layer below
        val glazeModifier = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Modifier
                .matchParentSize()
                .blur(18.dp)
                .background(highlightGradient)
        } else {
            Modifier
                .matchParentSize()
                .background(highlightGradient)
        }
        Box(modifier = glazeModifier)
        content()
    }
}
