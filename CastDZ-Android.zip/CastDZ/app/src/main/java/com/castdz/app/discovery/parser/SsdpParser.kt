package com.castdz.app.discovery.parser

data class SsdpResponse(
    val location: String?,
    val usn: String?,
    val st: String?,
    val server: String?,
    val uuid: String?,
    val isRoku: Boolean
)

/**
 * Pure Kotlin parser for SSDP M-SEARCH UDP responses.
 */
object SsdpParser {

    private val uuidRegex = Regex("uuid:([a-zA-Z0-9\\-]+)", RegexOption.IGNORE_CASE)

    fun parse(rawPacket: String): SsdpResponse? {
        val lines = rawPacket.split("\r\n", "\n")
        if (lines.isEmpty()) return null
        val statusLine = lines.first().trim()
        if (!statusLine.startsWith("HTTP/1.", ignoreCase = true) &&
            !statusLine.startsWith("NOTIFY", ignoreCase = true)
        ) {
            return null
        }

        val headers = mutableMapOf<String, String>()
        for (i in 1 until lines.size) {
            val line = lines[i].trim()
            if (line.isEmpty()) continue
            val colonIdx = line.indexOf(':')
            if (colonIdx > 0) {
                val key = line.substring(0, colonIdx).trim().lowercase()
                val value = line.substring(colonIdx + 1).trim()
                headers[key] = value
            }
        }

        val location = headers["location"]?.takeIf { it.startsWith("http", ignoreCase = true) }
        val usn = headers["usn"]
        val st = headers["st"] ?: headers["nt"]
        val server = headers["server"]
        val uuid = extractUuid(usn)
        val isRoku = st?.contains("roku:ecp", ignoreCase = true) == true ||
            usn?.contains("roku:ecp", ignoreCase = true) == true ||
            server?.contains("roku", ignoreCase = true) == true

        if (location == null && uuid == null) return null

        return SsdpResponse(
            location = location,
            usn = usn,
            st = st,
            server = server,
            uuid = uuid,
            isRoku = isRoku
        )
    }

    fun extractUuid(usn: String?): String? {
        if (usn.isNullOrBlank()) return null
        return uuidRegex.find(usn)?.groupValues?.getOrNull(1)?.lowercase()
    }
}
