package com.castdz.app.ui.theme

import androidx.compose.ui.graphics.Color

// Core CastDZ Brand Palette (from logo)
val DeepNavy = Color(0xFF0A0830)
val CosmicIndigo = Color(0xFF1A0F4D)
val AbyssalTeal = Color(0xFF07203A)

val AccentCyan = Color(0xFF00E5FF)
val AccentViolet = Color(0xFF7C4DFF)
val AccentPink = Color(0xFFFF2BD6)
val AccentAmber = Color(0xFFFFB020)
val AccentGreen = Color(0xFF00D67D)

// Dark Surfaces & Glass Tokens
val GlassDarkSurface = Color(0x2BFFFFFF)
val GlassDarkSurfaceElevated = Color(0x3D1E1A4A)
val GlassDarkBorder = Color(0x38FFFFFF)
val OnDarkPrimary = Color(0xFFF6F8FF)
val OnDarkSecondary = Color(0xFFB4BDDD)

// Light Mode Matching Palette
val LightBgStart = Color(0xFFF1F5FF)
val LightBgMid = Color(0xFFE9E6FF)
val LightBgEnd = Color(0xFFE3F5FC)
val GlassLightSurface = Color(0xB8FFFFFF)
val GlassLightBorder = Color(0x80FFFFFF)
val OnLightPrimary = Color(0xFF0E1233)
val OnLightSecondary = Color(0xFF475072)
