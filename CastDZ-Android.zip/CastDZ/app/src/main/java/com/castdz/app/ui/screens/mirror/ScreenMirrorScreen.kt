package com.castdz.app.ui.screens.mirror

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ScreenShare
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.airbnb.lottie.compose.LottieAnimation
import com.airbnb.lottie.compose.LottieCompositionSpec
import com.airbnb.lottie.compose.LottieConstants
import com.airbnb.lottie.compose.rememberLottieComposition
import com.castdz.app.R
import com.castdz.app.core.motion.rememberReduceMotionEnabled
import com.castdz.app.discovery.model.CastDevice
import com.castdz.app.ui.components.GlassCard
import com.castdz.app.ui.components.Icon3D
import com.castdz.app.ui.theme.AccentCyan
import com.castdz.app.ui.theme.AccentGreen
import com.castdz.app.ui.theme.AccentViolet

@Composable
fun ScreenMirrorScreen(
    detectedDevices: List<CastDevice>,
    isScanning: Boolean
) {
    val context = LocalContext.current
    val haptics = LocalHapticFeedback.current
    val reduceMotion = rememberReduceMotionEnabled()
    val primaryScreen = detectedDevices.firstOrNull()
    val fallbackError = stringResource(R.string.mirror_fallback_error)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp)
            .padding(bottom = 110.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            cornerRadius = 28.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(contentAlignment = Alignment.Center) {
                    val comp by rememberLottieComposition(
                        LottieCompositionSpec.RawRes(
                            if (primaryScreen != null) R.raw.lottie_success else R.raw.lottie_scanning
                        )
                    )
                    LottieAnimation(
                        composition = comp,
                        iterations = if (primaryScreen != null || reduceMotion) 1 else LottieConstants.IterateForever,
                        modifier = Modifier.size(140.dp)
                    )
                    Icon3D(
                        imageVector = Icons.Rounded.ScreenShare,
                        contentDescription = null,
                        gradientColors = listOf(AccentCyan, AccentViolet),
                        size = 60.dp,
                        iconSize = 30.dp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = stringResource(R.string.mirror_title),
                    style = MaterialTheme.typography.headlineSmall,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = stringResource(R.string.mirror_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Live discovery status banner: "Screen found: <name>"
                GlassCard(
                    cornerRadius = 18.dp,
                    borderColor = if (primaryScreen != null) AccentGreen.copy(alpha = 0.7f) else null
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (primaryScreen != null) {
                            Icon(
                                imageVector = Icons.Rounded.CheckCircle,
                                contentDescription = null,
                                tint = AccentGreen,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = stringResource(R.string.mirror_screen_found, primaryScreen.name),
                                style = MaterialTheme.typography.titleMedium,
                                color = AccentGreen,
                                textAlign = TextAlign.Center
                            )
                        } else {
                            Text(
                                text = stringResource(
                                    if (isScanning) R.string.mirror_scanning else R.string.mirror_no_screen
                                ),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                        val launched = openSystemCastPanel(context)
                        if (!launched) {
                            Toast.makeText(context, fallbackError, Toast.LENGTH_LONG).show()
                        }
                    },
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AccentCyan,
                        contentColor = Color(0xFF0A0830)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                ) {
                    Icon(Icons.Rounded.ScreenShare, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.mirror_cta),
                        style = MaterialTheme.typography.titleMedium
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = stringResource(R.string.mirror_honest_note),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

/**
 * Opens Android's native Cast panel with OEM Smart View / Miracast / Display Settings fallbacks.
 */
private fun openSystemCastPanel(context: Context): Boolean {
    val candidates = listOf(
        Intent(Settings.ACTION_CAST_SETTINGS),
        Intent("android.settings.WIFI_DISPLAY_SETTINGS"),
        Intent().setComponent(
            ComponentName(
                "com.samsung.android.smartmirroring",
                "com.samsung.android.smartmirroring.CastingDialog"
            )
        ),
        Intent("com.samsung.wfd.LAUNCH_WFD_PICKER_DLG"),
        Intent(Settings.ACTION_DISPLAY_SETTINGS)
    )
    for (intent in candidates) {
        val launched = runCatching {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            true
        }.getOrDefault(false)
        if (launched) return true
    }
    return false
}
