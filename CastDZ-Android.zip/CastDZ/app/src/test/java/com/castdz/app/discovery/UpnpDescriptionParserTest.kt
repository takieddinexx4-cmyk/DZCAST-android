package com.castdz.app.discovery

import com.castdz.app.discovery.parser.UpnpDescriptionParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class UpnpDescriptionParserTest {

    @Test
    fun parseSamsungDlnaXml_extractsFriendlyNameAndControlUrls() {
        val xml = """
            <?xml version="1.0" encoding="utf-8"?>
            <root xmlns="urn:schemas-upnp-org:device-1-0">
              <device>
                <deviceType>urn:schemas-upnp-org:device:MediaRenderer:1</deviceType>
                <friendlyName>Living Room &amp; QLED TV</friendlyName>
                <manufacturer>Samsung Electronics</manufacturer>
                <modelName>QN65Q80C</modelName>
                <UDN>uuid:11112222-3333-4444-5555-666677778888</UDN>
                <serviceList>
                  <service>
                    <serviceType>urn:schemas-upnp-org:service:AVTransport:1</serviceType>
                    <controlURL>/upnp/control/AVTransport1</controlURL>
                  </service>
                  <service>
                    <serviceType>urn:schemas-upnp-org:service:RenderingControl:1</serviceType>
                    <controlURL>/upnp/control/RenderingControl1</controlURL>
                  </service>
                </serviceList>
              </device>
            </root>
        """.trimIndent()

        val result = UpnpDescriptionParser.parse(xml, "http://192.168.1.55:9197/dmr")
        assertNotNull(result)
        assertEquals("Living Room & QLED TV", result!!.friendlyName)
        assertEquals("Samsung Electronics", result.manufacturer)
        assertEquals("QN65Q80C", result.modelName)
        assertEquals("11112222-3333-4444-5555-666677778888", result.udn)
        assertEquals("http://192.168.1.55:9197/upnp/control/AVTransport1", result.avTransportControlUrl)
        assertEquals("http://192.168.1.55:9197/upnp/control/RenderingControl1", result.renderingControlUrl)
    }

    @Test
    fun parseXmlWithoutDeviceTag_returnsNull() {
        assertNull(UpnpDescriptionParser.parse("<html/>", "http://192.168.1.1/"))
    }
}
