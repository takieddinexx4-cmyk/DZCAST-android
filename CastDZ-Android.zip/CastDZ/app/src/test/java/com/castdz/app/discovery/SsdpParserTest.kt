package com.castdz.app.discovery

import com.castdz.app.discovery.parser.SsdpParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SsdpParserTest {

    @Test
    fun parseDlnaMediaRendererResponse_extractsLocationUuidAndSt() {
        val raw = """
            HTTP/1.1 200 OK
            CACHE-CONTROL: max-age=1800
            LOCATION: http://192.168.1.55:9197/dmr
            SERVER: Samsung-Linux/4.1 UPnP/1.0 Samsung_UPnP_SDK/1.0
            ST: urn:schemas-upnp-org:device:MediaRenderer:1
            USN: uuid:7f8e9d0c-1234-5678-90ab-cdef12345678::urn:schemas-upnp-org:device:MediaRenderer:1
            
        """.trimIndent()

        val parsed = SsdpParser.parse(raw)
        assertNotNull(parsed)
        assertEquals("http://192.168.1.55:9197/dmr", parsed!!.location)
        assertEquals("7f8e9d0c-1234-5678-90ab-cdef12345678", parsed.uuid)
        assertEquals("urn:schemas-upnp-org:device:MediaRenderer:1", parsed.st)
        assertFalse(parsed.isRoku)
    }

    @Test
    fun parseRokuEcpResponse_marksIsRokuTrue() {
        val raw = """
            HTTP/1.1 200 OK
            LOCATION: http://192.168.1.73:8060/
            SERVER: Roku/12.5.0 UPnP/1.0 Roku/12.5.0
            ST: roku:ecp
            USN: uuid:roku:ecp:YR0012345678
        """.trimIndent()

        val parsed = SsdpParser.parse(raw)
        assertNotNull(parsed)
        assertTrue(parsed!!.isRoku)
        assertEquals("http://192.168.1.73:8060/", parsed.location)
    }

    @Test
    fun parseInvalidPacket_returnsNull() {
        assertNull(SsdpParser.parse("GARBAGE DATA"))
        assertNull(SsdpParser.parse(""))
    }
}
