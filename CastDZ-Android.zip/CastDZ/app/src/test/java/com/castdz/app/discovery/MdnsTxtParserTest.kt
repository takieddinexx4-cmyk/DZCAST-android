package com.castdz.app.discovery

import com.castdz.app.discovery.model.DeviceIconType
import com.castdz.app.discovery.parser.MdnsTxtParser
import org.junit.Assert.assertEquals
import org.junit.Test

class MdnsTxtParserTest {

    @Test
    fun parseGoogleCastAttributes_extractsFriendlyNameModelAndUuid() {
        val attrs = mapOf(
            "fn" to "Salon Chromecast".toByteArray(Charsets.UTF_8),
            "md" to "Chromecast Ultra".toByteArray(Charsets.UTF_8),
            "id" to "ABCDEF1234567890".toByteArray(Charsets.UTF_8),
            "ca" to "2052".toByteArray(Charsets.UTF_8)
        )

        val meta = MdnsTxtParser.parseAttributes(attrs)
        assertEquals("Salon Chromecast", meta.friendlyName)
        assertEquals("Chromecast Ultra", meta.model)
        assertEquals("abcdef1234567890", meta.uuid)
        assertEquals(2052, meta.capabilitiesMask)
        assertEquals(DeviceIconType.CHROMECAST, meta.inferIconType("_googlecast._tcp."))
    }

    @Test
    fun parseAirPlayRawLines_infersAppleTvIcon() {
        val lines = listOf(
            "fn=Bedroom Apple TV",
            "model=AppleTV11,1",
            "deviceid=AA:BB:CC:DD:EE:FF"
        )
        val meta = MdnsTxtParser.parseRawLines(lines)
        assertEquals("Bedroom Apple TV", meta.friendlyName)
        assertEquals("AppleTV11,1", meta.model)
        assertEquals("aa:bb:cc:dd:ee:ff", meta.uuid)
        assertEquals(DeviceIconType.APPLE_TV, meta.inferIconType("_airplay._tcp."))
    }
}
