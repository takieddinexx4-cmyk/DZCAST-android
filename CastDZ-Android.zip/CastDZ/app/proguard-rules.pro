# CastDZ ProGuard / R8 Rules

# Keep Google Cast OptionsProvider
-keep class com.castdz.app.CastOptionsProvider { *; }
-keep class com.google.android.gms.cast.framework.** { *; }

# Keep WebView JavascriptInterface bridge
-keepclassmembers class com.castdz.app.ui.screens.browser.VideoDetectionJsBridge {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep Room entities
-keep class com.castdz.app.data.local.entity.** { *; }

# Keep NanoHTTPD
-keep class fi.iki.elonen.** { *; }
-dontwarn fi.iki.elonen.**

# Keep Lottie
-keep class com.airbnb.lottie.** { *; }
