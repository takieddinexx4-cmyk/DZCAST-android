# CastDZ — Cast your screen with one touch

**CastDZ** is a modern, ad-free Android casting app built with **Kotlin**, **Jetpack Compose (Material 3)**, **Hilt (KSP)**, **Room**, **DataStore**, **Media3 ExoPlayer**, **Google Cast SDK**, **DLNA/UPnP**, **mDNS/NsdManager**, **NanoHTTPD**, and **Lottie**.

---

## Features

1. **Multi-Layer Device Discovery Engine (`com.castdz.app.discovery`)**
   - **Layer 1 — Google Cast:** `MediaRouter` + `MediaRouteSelector` using `CastMediaControlIntent.DEFAULT_MEDIA_RECEIVER_APPLICATION_ID` (no Cast developer registration or API key required). Active scanning while the device sheet is open, passive scanning otherwise.
   - **Layer 2 — mDNS / DNS-SD:** `NsdManager` scanning `_googlecast._tcp.`, `_airplay._tcp.`, and `_androidtvremote2._tcp.` with TXT record parsing (`fn`, `md`, `id`).
   - **Layer 3 — SSDP / UPnP / Roku:** Wi-Fi-bound UDP multicast (`239.255.255.250:1900`) sending `M-SEARCH` for `MediaRenderer:1`, `ssdp:all`, and `roku:ecp` every 2s for the first 10s, then every 15s, fetching `LOCATION` XML descriptions and extracting `AVTransport:1` and `RenderingControl:1` SOAP control URLs.
   - **Layer 4 — Manual IP Fallback:** Add any TV by IP and protocol directly from the device sheet.
   - **Robustness:** `WifiManager.MulticastLock` lifecycle management, `ConnectivityManager` Wi-Fi socket binding (works even with mobile data enabled), automatic rescan on network change, 30s stale-device eviction, background pause, and an 8-second diagnostic assistant with one-tap fixes (Wi-Fi off, mobile data only, missing permission, VPN active, router AP/client isolation).
   - **Debug Mode:** Toggle **Settings → Simulated devices (Debug)** to test the UI without physical TVs nearby.

2. **Web Video Browser & Local Media Casting**
   - Multi-tab WebView with URL/search bar, Room bookmarks, `shouldInterceptRequest` detection (`.mp4`, `.m3u8`, `.mpd`, `.webm`), injected `<video>`/`<source>` JS scanner, and a floating **"Cast this video"** pill. DRM-protected streams are respected and never bypassed.
   - Local Videos, Photos, and Music browser backed by `MediaStore`, with **Media3 ExoPlayer** local preview and an embedded **NanoHTTPD** HTTP server supporting `206 Partial Content` Range streaming over Wi-Fi.

3. **Cast Remote, Lock-Screen Controls & Screen Mirroring**
   - Persistent glass mini-player and expanded player sheet (play/pause, seek, volume, subtitles URL/toggle, queue management) plus a foreground `CastPlaybackService` notification for lock-screen controls.
   - Honest one-tap **Mirror my screen** flow: displays `Screen found: <name>` live from the discovery engine and launches Android's native Cast / Smart View / Wireless Display panel.

4. **Design System & Localization**
   - Deep cosmic gradient (`#0A0830 → #1A0F4D → #07203A`) with cyan/violet/pink/amber/green accents, translucent glassmorphism (RenderEffect blur on Android 12+, translucent fallback below), depth-styled 3D icons with gyroscope parallax, Lottie animations, haptics, and full `ANIMATOR_DURATION_SCALE` reduce-motion support.
   - Complete **English**, **French**, and **Arabic** localization with full RTL mirroring and instant in-app switching via `AppCompatDelegate.setApplicationLocales`.

---

## Build & Run

### Prerequisites
- **Android Studio** Ladybug / Meerkat or newer (JDK 17+)
- **Android SDK Platform 36** (`compileSdk = 36`, `targetSdk = 36`, `minSdk = 26`)

### Build Debug APK
```bash
# If gradle-wrapper.jar is not yet bootstrapped, initialize the wrapper once:
gradle wrapper --gradle-version 8.14.3

# Build debug APK
./gradlew assembleDebug

# Run unit tests (SSDP, UPnP XML, mDNS TXT parsers)
./gradlew testDebugUnitTest
```

The APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`

---

## Design Decisions & Notes

- **Target SDK 36 & `ACCESS_LOCAL_NETWORK`:** Targets the latest stable Android 16 (API 36). Per Android documentation, `ACCESS_LOCAL_NETWORK` is only required when `targetSdk >= 37` (Android 17+); on API 36 and below, local network access is implicitly granted via `INTERNET` alongside `NEARBY_WIFI_DEVICES` (`neverForLocation`) on API 33+ and `ACCESS_FINE_LOCATION` (`maxSdkVersion="32"`) on API 26–32.
- **Cleartext Local Network Policy:** Android's `network-security-config` `<domain>` attribute does not accept CIDR subnets (`192.168.0.0/16`). `network_security_config.xml` allows local LAN HTTP for DLNA/NanoHTTPD while `LocalNetworkSecurityInterceptor` in OkHttp strictly blocks cleartext HTTP to any non-RFC1918/non-local host.
- **Bundled Fonts:** Inter (`inter_*.otf`) is bundled for Latin scripts and a geometric Arabic typeface (`cairo_*.ttf`, offline-bundled Noto Kufi Arabic) is included so `./gradlew assembleDebug` builds cleanly with zero network font downloads. You can drop official `Cairo-Regular.ttf` / `Cairo-Bold.ttf` from Google Fonts directly over `app/src/main/res/font/cairo_*.ttf` at any time.
